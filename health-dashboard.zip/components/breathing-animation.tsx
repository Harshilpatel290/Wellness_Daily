"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Slider } from "@/components/ui/slider"
import { Play, Pause, RefreshCw } from "lucide-react"
import { motion, AnimatePresence } from "framer-motion"

export function BreathingAnimation() {
  const [isActive, setIsActive] = useState(false)
  const [phase, setPhase] = useState<"inhale" | "hold" | "exhale" | "rest">("inhale")
  const [timer, setTimer] = useState(0)
  const [inhaleDuration, setInhaleDuration] = useState(4)
  const [holdDuration, setHoldDuration] = useState(4)
  const [exhaleDuration, setExhaleDuration] = useState(4)
  const [restDuration, setRestDuration] = useState(2)
  const [cycles, setCycles] = useState(0)

  useEffect(() => {
    let interval: NodeJS.Timeout | null = null

    if (isActive) {
      interval = setInterval(() => {
        setTimer((prevTimer) => {
          const newTimer = prevTimer + 0.1

          // Determine phase transitions
          if (phase === "inhale" && newTimer >= inhaleDuration) {
            setPhase("hold")
            return 0
          } else if (phase === "hold" && newTimer >= holdDuration) {
            setPhase("exhale")
            return 0
          } else if (phase === "exhale" && newTimer >= exhaleDuration) {
            setPhase("rest")
            return 0
          } else if (phase === "rest" && newTimer >= restDuration) {
            setPhase("inhale")
            setCycles((prev) => prev + 1)
            return 0
          }

          return newTimer
        })
      }, 100)
    }

    return () => {
      if (interval) clearInterval(interval)
    }
  }, [isActive, phase, inhaleDuration, holdDuration, exhaleDuration, restDuration])

  const resetExercise = () => {
    setIsActive(false)
    setPhase("inhale")
    setTimer(0)
    setCycles(0)
  }

  const getPhaseText = () => {
    switch (phase) {
      case "inhale":
        return "Inhale"
      case "hold":
        return "Hold"
      case "exhale":
        return "Exhale"
      case "rest":
        return "Rest"
    }
  }

  const getPhaseDuration = () => {
    switch (phase) {
      case "inhale":
        return inhaleDuration
      case "hold":
        return holdDuration
      case "exhale":
        return exhaleDuration
      case "rest":
        return restDuration
    }
  }

  const getProgressPercentage = () => {
    return (timer / getPhaseDuration()) * 100
  }

  const getPhaseColor = () => {
    switch (phase) {
      case "inhale":
        return "from-blue-300 to-cyan-300 dark:from-blue-600 dark:to-cyan-600"
      case "hold":
        return "from-green-300 to-emerald-300 dark:from-green-600 dark:to-emerald-600"
      case "exhale":
        return "from-purple-300 to-violet-300 dark:from-purple-600 dark:to-violet-600"
      case "rest":
        return "from-gray-300 to-slate-300 dark:from-gray-600 dark:to-slate-600"
    }
  }

  return (
    <div className="grid gap-6 md:grid-cols-2">
      <Card className="overflow-hidden border-none bg-background/60 backdrop-blur-lg shadow-xl">
        <CardHeader className="bg-gradient-to-r from-purple-500/10 to-indigo-500/10 dark:from-purple-500/20 dark:to-indigo-500/20">
          <CardTitle>Breathing Exercise</CardTitle>
          <CardDescription>Follow the animation for guided breathing</CardDescription>
        </CardHeader>
        <CardContent className="p-6 flex flex-col items-center">
          <div className="relative flex items-center justify-center mb-8 h-64 w-full">
            <AnimatePresence mode="wait">
              <motion.div
                key={phase}
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                transition={{ duration: 0.5 }}
                className={`absolute inset-0 bg-gradient-to-r ${getPhaseColor()} rounded-full opacity-10`}
                style={{
                  scale: isActive ? 1 : 0.5,
                }}
              />
            </AnimatePresence>

            <motion.div
              animate={{
                scale: phase === "inhale" ? [1, 1.5] : phase === "hold" ? 1.5 : phase === "exhale" ? [1.5, 1] : 1,
              }}
              transition={{
                duration: phase === "inhale" ? inhaleDuration : phase === "exhale" ? exhaleDuration : 0,
                ease: "easeInOut",
                times: [0, 1],
              }}
              className={`absolute rounded-full border-4 transition-colors duration-500 flex items-center justify-center
                ${
                  phase === "inhale"
                    ? "border-blue-400 dark:border-blue-500"
                    : phase === "hold"
                      ? "border-green-400 dark:border-green-500"
                      : phase === "exhale"
                        ? "border-purple-400 dark:border-purple-500"
                        : "border-gray-400 dark:border-gray-500"
                }`}
              style={{
                height: "60%",
                width: "60%",
              }}
            >
              <div className="text-2xl font-bold">{getPhaseText()}</div>
            </motion.div>
          </div>

          <div className="text-center mb-6">
            <div className="text-sm text-muted-foreground">Current Phase</div>
            <div className="text-xl font-bold">{getPhaseText()}</div>
            <div className="text-sm text-muted-foreground">
              {Math.floor(timer)}.{Math.floor((timer % 1) * 10)}s / {getPhaseDuration()}s
            </div>
          </div>

          <div className="flex gap-4 mb-4">
            <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
              <Button
                variant="outline"
                size="icon"
                onClick={() => setIsActive(!isActive)}
                className="bg-gradient-to-r from-purple-100 to-indigo-100 dark:from-purple-900/30 dark:to-indigo-900/30 hover:from-purple-200 hover:to-indigo-200 dark:hover:from-purple-900/50 dark:hover:to-indigo-900/50"
              >
                {isActive ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4" />}
              </Button>
            </motion.div>
            <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
              <Button
                variant="outline"
                size="icon"
                onClick={resetExercise}
                className="bg-gradient-to-r from-purple-100 to-indigo-100 dark:from-purple-900/30 dark:to-indigo-900/30 hover:from-purple-200 hover:to-indigo-200 dark:hover:from-purple-900/50 dark:hover:to-indigo-900/50"
              >
                <RefreshCw className="h-4 w-4" />
              </Button>
            </motion.div>
          </div>

          <div className="text-sm text-muted-foreground">Completed cycles: {cycles}</div>
        </CardContent>
      </Card>

      <Card className="overflow-hidden border-none bg-background/60 backdrop-blur-lg shadow-xl">
        <CardHeader className="bg-gradient-to-r from-purple-500/10 to-indigo-500/10 dark:from-purple-500/20 dark:to-indigo-500/20">
          <CardTitle>Breathing Settings</CardTitle>
          <CardDescription>Customize your breathing exercise</CardDescription>
        </CardHeader>
        <CardContent className="p-6">
          <div className="space-y-6">
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span>Inhale Duration</span>
                <span>{inhaleDuration}s</span>
              </div>
              <Slider
                value={[inhaleDuration]}
                min={2}
                max={10}
                step={1}
                onValueChange={(value) => setInhaleDuration(value[0])}
                disabled={isActive}
                className="[&>span]:bg-blue-500 dark:[&>span]:bg-blue-400"
              />
            </div>

            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span>Hold Duration</span>
                <span>{holdDuration}s</span>
              </div>
              <Slider
                value={[holdDuration]}
                min={0}
                max={10}
                step={1}
                onValueChange={(value) => setHoldDuration(value[0])}
                disabled={isActive}
                className="[&>span]:bg-green-500 dark:[&>span]:bg-green-400"
              />
            </div>

            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span>Exhale Duration</span>
                <span>{exhaleDuration}s</span>
              </div>
              <Slider
                value={[exhaleDuration]}
                min={2}
                max={10}
                step={1}
                onValueChange={(value) => setExhaleDuration(value[0])}
                disabled={isActive}
                className="[&>span]:bg-purple-500 dark:[&>span]:bg-purple-400"
              />
            </div>

            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span>Rest Duration</span>
                <span>{restDuration}s</span>
              </div>
              <Slider
                value={[restDuration]}
                min={0}
                max={5}
                step={1}
                onValueChange={(value) => setRestDuration(value[0])}
                disabled={isActive}
                className="[&>span]:bg-gray-500 dark:[&>span]:bg-gray-400"
              />
            </div>

            <div className="pt-2">
              <motion.div whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }}>
                <Button
                  className="w-full bg-gradient-to-r from-purple-500 to-indigo-500 hover:from-purple-600 hover:to-indigo-600"
                  onClick={() => {
                    setInhaleDuration(4)
                    setHoldDuration(4)
                    setExhaleDuration(4)
                    setRestDuration(2)
                  }}
                  disabled={isActive}
                >
                  Reset to Default
                </Button>
              </motion.div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
