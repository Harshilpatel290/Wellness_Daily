"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Checkbox } from "@/components/ui/checkbox"
import { Progress } from "@/components/ui/progress"
import { Play, Pause, RotateCcw, Plus, Trash2, Clock } from "lucide-react"
import { motion, AnimatePresence } from "framer-motion"

interface Exercise {
  id: string
  name: string
  duration: number
  completed: boolean
}

export function FitnessRoutine() {
  const [exercises, setExercises] = useState<Exercise[]>([
    { id: "1", name: "Warm-up", duration: 300, completed: false },
    { id: "2", name: "Push-ups", duration: 180, completed: false },
    { id: "3", name: "Squats", duration: 180, completed: false },
    { id: "4", name: "Plank", duration: 60, completed: false },
    { id: "5", name: "Jumping Jacks", duration: 120, completed: false },
    { id: "6", name: "Cool Down", duration: 180, completed: false },
  ])

  const [activeExercise, setActiveExercise] = useState<string | null>(null)
  const [timer, setTimer] = useState(0)
  const [isRunning, setIsRunning] = useState(false)

  const [newExercise, setNewExercise] = useState({
    name: "",
    duration: 60,
  })

  useEffect(() => {
    let interval: NodeJS.Timeout | null = null

    if (isRunning && activeExercise) {
      interval = setInterval(() => {
        setTimer((prevTimer) => {
          const newTimer = prevTimer + 1
          const exercise = exercises.find((ex) => ex.id === activeExercise)

          if (exercise && newTimer >= exercise.duration) {
            setIsRunning(false)
            markExerciseComplete(activeExercise)
            return 0
          }

          return newTimer
        })
      }, 1000)
    }

    return () => {
      if (interval) clearInterval(interval)
    }
  }, [isRunning, activeExercise, exercises])

  const startExercise = (id: string) => {
    setActiveExercise(id)
    setTimer(0)
    setIsRunning(true)
  }

  const toggleTimer = () => {
    setIsRunning(!isRunning)
  }

  const resetTimer = () => {
    setTimer(0)
    setIsRunning(false)
  }

  const markExerciseComplete = (id: string) => {
    setExercises(exercises.map((exercise) => (exercise.id === id ? { ...exercise, completed: true } : exercise)))
  }

  const toggleExerciseComplete = (id: string) => {
    setExercises(
      exercises.map((exercise) => (exercise.id === id ? { ...exercise, completed: !exercise.completed } : exercise)),
    )
  }

  const handleAddExercise = () => {
    if (newExercise.name && newExercise.duration > 0) {
      setExercises([
        ...exercises,
        {
          id: Date.now().toString(),
          name: newExercise.name,
          duration: newExercise.duration,
          completed: false,
        },
      ])
      setNewExercise({
        name: "",
        duration: 60,
      })
    }
  }

  const handleDeleteExercise = (id: string) => {
    setExercises(exercises.filter((exercise) => exercise.id !== id))
    if (activeExercise === id) {
      setActiveExercise(null)
      setTimer(0)
      setIsRunning(false)
    }
  }

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60)
    const secs = seconds % 60
    return `${mins.toString().padStart(2, "0")}:${secs.toString().padStart(2, "0")}`
  }

  const completedExercises = exercises.filter((ex) => ex.completed).length
  const progressPercentage = (completedExercises / exercises.length) * 100

  const activeExerciseObj = activeExercise ? exercises.find((ex) => ex.id === activeExercise) : null

  return (
    <div className="grid gap-6 md:grid-cols-2">
      <Card className="overflow-hidden border-none bg-background/60 backdrop-blur-lg shadow-xl">
        <CardHeader className="bg-gradient-to-r from-red-500/10 to-pink-500/10 dark:from-red-500/20 dark:to-pink-500/20">
          <CardTitle>Fitness Routine</CardTitle>
          <CardDescription>Track your workout exercises</CardDescription>
        </CardHeader>
        <CardContent className="p-6">
          <div className="space-y-4 mb-6">
            <div className="grid grid-cols-2 gap-4">
              <motion.div
                className="col-span-2 md:col-span-1"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.1 }}
              >
                <div className="text-center p-4 bg-gradient-to-br from-red-100 to-pink-100 dark:from-red-900/30 dark:to-pink-900/30 rounded-lg">
                  <div className="text-sm text-muted-foreground">Progress</div>
                  <div className="text-2xl font-bold">
                    {completedExercises}/{exercises.length}
                  </div>
                  <div className="text-xs text-muted-foreground">exercises completed</div>
                </div>
              </motion.div>
              <motion.div
                className="col-span-2 md:col-span-1"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.2 }}
              >
                <div className="text-center p-4 bg-gradient-to-br from-red-100 to-pink-100 dark:from-red-900/30 dark:to-pink-900/30 rounded-lg">
                  <div className="text-sm text-muted-foreground">Total Time</div>
                  <div className="text-2xl font-bold">
                    {formatTime(exercises.reduce((sum, ex) => sum + ex.duration, 0))}
                  </div>
                  <div className="text-xs text-muted-foreground">workout duration</div>
                </div>
              </motion.div>
            </div>

            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span>Workout Progress</span>
                <span>
                  {completedExercises}/{exercises.length} completed
                </span>
              </div>
              <Progress
                value={progressPercentage}
                className="h-3 [&>div]:bg-gradient-to-r [&>div]:from-red-500 [&>div]:to-pink-500"
              />
            </div>
          </div>

          {activeExerciseObj && (
            <motion.div
              className="mb-6 p-4 border rounded-lg bg-gradient-to-r from-red-50 to-pink-50 dark:from-red-900/10 dark:to-pink-900/10"
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.3 }}
            >
              <div className="text-center mb-4">
                <h3 className="text-lg font-bold">{activeExerciseObj.name}</h3>
                <div className="text-sm text-muted-foreground">
                  {formatTime(timer)} / {formatTime(activeExerciseObj.duration)}
                </div>
              </div>

              <Progress
                value={(timer / activeExerciseObj.duration) * 100}
                className="h-3 mb-4 [&>div]:bg-gradient-to-r [&>div]:from-red-500 [&>div]:to-pink-500"
              />

              <div className="flex justify-center gap-2">
                <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                  <Button
                    variant="outline"
                    size="icon"
                    onClick={toggleTimer}
                    className="bg-gradient-to-r from-red-100 to-pink-100 dark:from-red-900/30 dark:to-pink-900/30 hover:from-red-200 hover:to-pink-200 dark:hover:from-red-900/50 dark:hover:to-pink-900/50"
                  >
                    {isRunning ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4" />}
                  </Button>
                </motion.div>
                <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                  <Button
                    variant="outline"
                    size="icon"
                    onClick={resetTimer}
                    className="bg-gradient-to-r from-red-100 to-pink-100 dark:from-red-900/30 dark:to-pink-900/30 hover:from-red-200 hover:to-pink-200 dark:hover:from-red-900/50 dark:hover:to-pink-900/50"
                  >
                    <RotateCcw className="h-4 w-4" />
                  </Button>
                </motion.div>
              </div>
            </motion.div>
          )}

          <div className="space-y-4">
            <div className="grid gap-2">
              <Label htmlFor="exercise-name">Exercise Name</Label>
              <Input
                id="exercise-name"
                placeholder="Enter exercise name"
                value={newExercise.name}
                onChange={(e) => setNewExercise({ ...newExercise, name: e.target.value })}
              />
            </div>

            <div className="grid gap-2">
              <Label htmlFor="exercise-duration">Duration (seconds)</Label>
              <Input
                id="exercise-duration"
                type="number"
                min="5"
                step="5"
                value={newExercise.duration}
                onChange={(e) => setNewExercise({ ...newExercise, duration: Number.parseInt(e.target.value) || 60 })}
              />
            </div>

            <motion.div whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }}>
              <Button
                className="w-full bg-gradient-to-r from-red-500 to-pink-500 hover:from-red-600 hover:to-pink-600"
                onClick={handleAddExercise}
                disabled={!newExercise.name || newExercise.duration <= 0}
              >
                <Plus className="mr-2 h-4 w-4" /> Add Exercise
              </Button>
            </motion.div>
          </div>
        </CardContent>
      </Card>

      <Card className="overflow-hidden border-none bg-background/60 backdrop-blur-lg shadow-xl">
        <CardHeader className="bg-gradient-to-r from-red-500/10 to-pink-500/10 dark:from-red-500/20 dark:to-pink-500/20">
          <CardTitle>Exercise List</CardTitle>
          <CardDescription>Your workout routine</CardDescription>
        </CardHeader>
        <CardContent className="p-6">
          <AnimatePresence>
            <div className="space-y-4">
              {exercises.length === 0 ? (
                <div className="text-center py-6 text-muted-foreground">No exercises added yet</div>
              ) : (
                exercises.map((exercise, index) => (
                  <motion.div
                    key={exercise.id}
                    className={`flex items-center justify-between p-3 border rounded-lg ${
                      exercise.completed
                        ? "bg-muted/50"
                        : "bg-gradient-to-r from-red-50 to-pink-50 dark:from-red-900/10 dark:to-pink-900/10"
                    } ${activeExercise === exercise.id ? "ring-2 ring-primary" : ""}`}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -20 }}
                    transition={{ delay: index * 0.05 }}
                  >
                    <div className="flex items-center gap-3">
                      <Checkbox
                        checked={exercise.completed}
                        onCheckedChange={() => toggleExerciseComplete(exercise.id)}
                        id={`check-${exercise.id}`}
                      />
                      <div>
                        <Label
                          htmlFor={`check-${exercise.id}`}
                          className={`font-medium ${exercise.completed ? "line-through text-muted-foreground" : ""}`}
                        >
                          {exercise.name}
                        </Label>
                        <div className="flex items-center text-sm text-muted-foreground">
                          <Clock className="mr-1 h-3 w-3" />
                          {formatTime(exercise.duration)}
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      {!exercise.completed && (
                        <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => startExercise(exercise.id)}
                            disabled={activeExercise === exercise.id && isRunning}
                            className="bg-gradient-to-r from-red-100 to-pink-100 dark:from-red-900/30 dark:to-pink-900/30 hover:from-red-200 hover:to-pink-200 dark:hover:from-red-900/50 dark:hover:to-pink-900/50"
                          >
                            {activeExercise === exercise.id ? "Active" : "Start"}
                          </Button>
                        </motion.div>
                      )}
                      <Button variant="ghost" size="icon" onClick={() => handleDeleteExercise(exercise.id)}>
                        <Trash2 className="h-4 w-4 text-muted-foreground" />
                      </Button>
                    </div>
                  </motion.div>
                ))
              )}
            </div>
          </AnimatePresence>
        </CardContent>
        <CardFooter className="flex justify-between border-t px-6 py-4">
          <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
            <Button
              variant="outline"
              onClick={() => {
                setExercises(exercises.map((ex) => ({ ...ex, completed: false })))
                setActiveExercise(null)
                setTimer(0)
                setIsRunning(false)
              }}
              disabled={completedExercises === 0}
            >
              <RotateCcw className="mr-2 h-4 w-4" /> Reset All
            </Button>
          </motion.div>
          <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
            <Button
              className="bg-gradient-to-r from-red-500 to-pink-500 hover:from-red-600 hover:to-pink-600"
              onClick={() => {
                setExercises(exercises.map((ex) => ({ ...ex, completed: true })))
              }}
              disabled={completedExercises === exercises.length}
            >
              Complete All
            </Button>
          </motion.div>
        </CardFooter>
      </Card>
    </div>
  )
}
