"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import { Badge } from "@/components/ui/badge"
import { Skeleton } from "@/components/ui/skeleton"
import {
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  ResponsiveContainer,
  Area,
  AreaChart,
  Tooltip,
  Legend,
  ReferenceLine,
  ComposedChart,
  Bar,
  Scatter,
} from "recharts"
import {
  Activity,
  Heart,
  Droplet,
  Moon,
  Utensils,
  Dumbbell,
  Brain,
  Zap,
  Footprints,
  Watch,
  RefreshCw,
  Smartphone,
  ArrowUpRight,
  ArrowDownRight,
  Flame,
  Waves,
  Leaf,
  Thermometer,
  BarChart,
  LineChart,
  PieChart,
  Home,
} from "lucide-react"
import { motion } from "framer-motion"

export function HealthDashboard() {
  const [isLoading, setIsLoading] = useState(true)
  const [isSyncing, setIsSyncing] = useState(false)
  const [lastSynced, setLastSynced] = useState<Date | null>(null)
  const [activeTab, setActiveTab] = useState("overview")
  const [timeRange, setTimeRange] = useState("day")
  const [chartType, setChartType] = useState("area")

  // Simulate loading and data fetching
  useEffect(() => {
    const timer = setTimeout(() => {
      setIsLoading(false)
      setLastSynced(new Date())
    }, 1500)

    return () => clearTimeout(timer)
  }, [])

  const handleSync = () => {
    setIsSyncing(true)
    setTimeout(() => {
      setIsSyncing(false)
      setLastSynced(new Date())
    }, 2000)
  }

  // Mock data for the dashboard
  const activityData = [
    { time: "00:00", steps: 0, heartRate: 62, calories: 0 },
    { time: "03:00", steps: 0, heartRate: 58, calories: 0 },
    { time: "06:00", steps: 120, heartRate: 64, calories: 15 },
    { time: "09:00", steps: 1250, heartRate: 78, calories: 120 },
    { time: "12:00", steps: 3500, heartRate: 84, calories: 320 },
    { time: "15:00", steps: 5780, heartRate: 76, calories: 450 },
    { time: "18:00", steps: 8200, heartRate: 82, calories: 580 },
    { time: "21:00", steps: 9543, heartRate: 73, calories: 650 },
    { time: "23:59", steps: 9543, heartRate: 65, calories: 650 },
  ]

  const weeklyData = [
    { day: "Mon", steps: 8432, heartRate: 72, calories: 320, sleep: 7.2, stress: 35 },
    { day: "Tue", steps: 10567, heartRate: 70, calories: 420, sleep: 6.8, stress: 42 },
    { day: "Wed", steps: 7890, heartRate: 74, calories: 310, sleep: 7.5, stress: 38 },
    { day: "Thu", steps: 9123, heartRate: 71, calories: 380, sleep: 7.0, stress: 45 },
    { day: "Fri", steps: 11234, heartRate: 69, calories: 450, sleep: 7.8, stress: 30 },
    { day: "Sat", steps: 12567, heartRate: 68, calories: 510, sleep: 8.2, stress: 25 },
    { day: "Sun", steps: 6789, heartRate: 73, calories: 280, sleep: 7.4, stress: 32 },
  ]

  const monthlyData = [
    { week: "Week 1", steps: 58432, heartRate: 71, calories: 2320, sleep: 7.3, stress: 38 },
    { week: "Week 2", steps: 62567, heartRate: 72, calories: 2520, sleep: 7.1, stress: 40 },
    { week: "Week 3", steps: 67890, heartRate: 70, calories: 2710, sleep: 7.4, stress: 35 },
    { week: "Week 4", steps: 71234, heartRate: 69, calories: 2850, sleep: 7.5, stress: 32 },
  ]

  const sleepData = [
    { day: "Mon", deep: 2.1, light: 4.2, rem: 1.5, awake: 0.3 },
    { day: "Tue", deep: 1.8, light: 4.5, rem: 1.3, awake: 0.5 },
    { day: "Wed", deep: 2.3, light: 4.0, rem: 1.7, awake: 0.2 },
    { day: "Thu", deep: 1.9, light: 4.3, rem: 1.4, awake: 0.4 },
    { day: "Fri", deep: 2.0, light: 4.1, rem: 1.6, awake: 0.3 },
    { day: "Sat", deep: 2.5, light: 4.8, rem: 1.9, awake: 0.1 },
    { day: "Sun", deep: 2.2, light: 4.6, rem: 1.8, awake: 0.2 },
  ]

  const workoutData = [
    { name: "Running", duration: 35, calories: 320, heartRate: 145 },
    { name: "Cycling", duration: 45, calories: 380, heartRate: 135 },
    { name: "Swimming", duration: 30, calories: 250, heartRate: 130 },
    { name: "Strength", duration: 40, calories: 280, heartRate: 125 },
    { name: "Yoga", duration: 50, calories: 200, heartRate: 110 },
  ]

  const heartRateZones = [
    { name: "Rest (50-60%)", value: 15 },
    { name: "Light (60-70%)", value: 35 },
    { name: "Moderate (70-80%)", value: 30 },
    { name: "Intense (80-90%)", value: 15 },
    { name: "Maximum (90-100%)", value: 5 },
  ]

  const nutritionData = {
    calories: { consumed: 1850, goal: 2200 },
    protein: { consumed: 95, goal: 120 },
    carbs: { consumed: 210, goal: 250 },
    fat: { consumed: 65, goal: 70 },
    water: { consumed: 5, goal: 8 },
  }

  // Overlay data for combined charts
  const combinedActivityData = activityData.map((item) => ({
    ...item,
    stepsGoal: 10000,
    heartRateRest: 65,
    caloriesGoal: 700,
  }))

  // Get data based on selected time range
  const getTimeRangeData = () => {
    switch (timeRange) {
      case "day":
        return activityData
      case "week":
        return weeklyData
      case "month":
        return monthlyData
      default:
        return activityData
    }
  }

  const renderSkeleton = () => (
    <div className="space-y-6 animate-pulse">
      <div className="grid gap-6 md:grid-cols-4">
        {[1, 2, 3, 4].map((i) => (
          <Card key={i} className="overflow-hidden">
            <CardHeader className="pb-2">
              <Skeleton className="h-4 w-24" />
            </CardHeader>
            <CardContent>
              <Skeleton className="h-8 w-16 mb-2" />
              <Skeleton className="h-3 w-full" />
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        <Card className="md:col-span-2">
          <CardHeader>
            <Skeleton className="h-5 w-40" />
            <Skeleton className="h-4 w-60" />
          </CardHeader>
          <CardContent>
            <Skeleton className="h-[300px] w-full" />
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <Skeleton className="h-5 w-32" />
            <Skeleton className="h-4 w-48" />
          </CardHeader>
          <CardContent>
            <Skeleton className="h-[300px] w-full" />
          </CardContent>
        </Card>
      </div>
    </div>
  )

  const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-background/95 backdrop-blur-sm border rounded-lg shadow-lg p-3">
          <p className="font-medium text-sm">{label}</p>
          {payload.map((entry: any, index: number) => (
            <div key={`item-${index}`} className="flex items-center gap-2 text-xs mt-1">
              <div className="w-2 h-2 rounded-full" style={{ backgroundColor: entry.color }} />
              <span>
                {entry.name}: {entry.value} {entry.unit}
              </span>
            </div>
          ))}
        </div>
      )
    }

    return null
  }

  if (isLoading) {
    return renderSkeleton()
  }

  return (
    <div className="space-y-6">
      {/* Sync status bar */}
      <div className="flex items-center justify-between bg-background/60 backdrop-blur-sm border rounded-lg p-3 shadow-sm">
        <div className="flex items-center gap-2">
          <Watch className="h-5 w-5 text-emerald-500" />
          <span className="font-medium text-base">Health Tracker</span>
          {lastSynced && (
            <span className="text-xs text-muted-foreground ml-2">Last synced: {lastSynced.toLocaleTimeString()}</span>
          )}
        </div>
        <Button
          onClick={handleSync}
          disabled={isSyncing}
          size="sm"
          className="bg-emerald-500 hover:bg-emerald-600 text-white"
        >
          {isSyncing ? (
            <>
              <RefreshCw className="mr-2 h-3.5 w-3.5 animate-spin" />
              <span className="text-xs font-medium">Syncing...</span>
            </>
          ) : (
            <>
              <Smartphone className="mr-2 h-3.5 w-3.5" />
              <span className="text-xs font-medium">Sync Device</span>
            </>
          )}
        </Button>
      </div>

      {/* Dashboard tabs */}
      <div className="flex flex-col gap-4">
        <div className="flex flex-wrap items-center justify-center sm:justify-start gap-2 bg-background/60 backdrop-blur-sm border rounded-lg p-2">
          <Button
            variant={activeTab === "overview" ? "default" : "ghost"}
            onClick={() => setActiveTab("overview")}
            className={`flex items-center gap-1.5 h-9 px-3 text-sm font-medium ${
              activeTab === "overview" ? "bg-emerald-500 text-white hover:bg-emerald-600" : ""
            }`}
          >
            <Home className="h-4 w-4" />
            <span>Overview</span>
          </Button>
          <Button
            variant={activeTab === "activity" ? "default" : "ghost"}
            onClick={() => setActiveTab("activity")}
            className={`flex items-center gap-1.5 h-9 px-3 text-sm font-medium ${
              activeTab === "activity" ? "bg-blue-500 text-white hover:bg-blue-600" : ""
            }`}
          >
            <Activity className="h-4 w-4" />
            <span>Activity</span>
          </Button>
          <Button
            variant={activeTab === "sleep" ? "default" : "ghost"}
            onClick={() => setActiveTab("sleep")}
            className={`flex items-center gap-1.5 h-9 px-3 text-sm font-medium ${
              activeTab === "sleep" ? "bg-indigo-500 text-white hover:bg-indigo-600" : ""
            }`}
          >
            <Moon className="h-4 w-4" />
            <span>Sleep</span>
          </Button>
          <Button
            variant={activeTab === "nutrition" ? "default" : "ghost"}
            onClick={() => setActiveTab("nutrition")}
            className={`flex items-center gap-1.5 h-9 px-3 text-sm font-medium ${
              activeTab === "nutrition" ? "bg-amber-500 text-white hover:bg-amber-600" : ""
            }`}
          >
            <Utensils className="h-4 w-4" />
            <span>Nutrition</span>
          </Button>
        </div>

        {/* Time range and chart type selectors */}
        {(activeTab === "overview" || activeTab === "activity") && (
          <div className="flex flex-wrap items-center justify-between gap-2 bg-background/60 backdrop-blur-sm border rounded-lg p-2">
            <div className="flex items-center gap-1.5">
              <span className="text-xs font-medium text-muted-foreground mr-1">Time Range:</span>
              <Button
                variant={timeRange === "day" ? "secondary" : "outline"}
                size="sm"
                onClick={() => setTimeRange("day")}
                className={`h-7 px-2.5 text-xs font-medium ${
                  timeRange === "day"
                    ? "bg-emerald-100 text-emerald-700 border-emerald-200 dark:bg-emerald-900/30 dark:text-emerald-400 dark:border-emerald-800"
                    : ""
                }`}
              >
                <span>Today</span>
              </Button>
              <Button
                variant={timeRange === "week" ? "secondary" : "outline"}
                size="sm"
                onClick={() => setTimeRange("week")}
                className={`h-7 px-2.5 text-xs font-medium ${
                  timeRange === "week"
                    ? "bg-emerald-100 text-emerald-700 border-emerald-200 dark:bg-emerald-900/30 dark:text-emerald-400 dark:border-emerald-800"
                    : ""
                }`}
              >
                <span>This Week</span>
              </Button>
              <Button
                variant={timeRange === "month" ? "secondary" : "outline"}
                size="sm"
                onClick={() => setTimeRange("month")}
                className={`h-7 px-2.5 text-xs font-medium ${
                  timeRange === "month"
                    ? "bg-emerald-100 text-emerald-700 border-emerald-200 dark:bg-emerald-900/30 dark:text-emerald-400 dark:border-emerald-800"
                    : ""
                }`}
              >
                <span>This Month</span>
              </Button>
            </div>

            <div className="flex items-center gap-1.5">
              <span className="text-xs font-medium text-muted-foreground mr-1">Chart Type:</span>
              <Button
                variant={chartType === "area" ? "secondary" : "outline"}
                size="sm"
                onClick={() => setChartType("area")}
                className={`h-7 w-7 p-0 ${
                  chartType === "area"
                    ? "bg-emerald-100 text-emerald-700 border-emerald-200 dark:bg-emerald-900/30 dark:text-emerald-400 dark:border-emerald-800"
                    : ""
                }`}
                title="Area Chart"
              >
                <BarChart className="h-3.5 w-3.5" />
              </Button>
              <Button
                variant={chartType === "line" ? "secondary" : "outline"}
                size="sm"
                onClick={() => setChartType("line")}
                className={`h-7 w-7 p-0 ${
                  chartType === "line"
                    ? "bg-emerald-100 text-emerald-700 border-emerald-200 dark:bg-emerald-900/30 dark:text-emerald-400 dark:border-emerald-800"
                    : ""
                }`}
                title="Line Chart"
              >
                <LineChart className="h-3.5 w-3.5" />
              </Button>
              <Button
                variant={chartType === "composed" ? "secondary" : "outline"}
                size="sm"
                onClick={() => setChartType("composed")}
                className={`h-7 w-7 p-0 ${
                  chartType === "composed"
                    ? "bg-emerald-100 text-emerald-700 border-emerald-200 dark:bg-emerald-900/30 dark:text-emerald-400 dark:border-emerald-800"
                    : ""
                }`}
                title="Combined Chart"
              >
                <PieChart className="h-3.5 w-3.5" />
              </Button>
            </div>
          </div>
        )}
      </div>

      {/* Overview Tab */}
      {activeTab === "overview" && (
        <div className="space-y-6">
          <div className="grid gap-4 md:grid-cols-4">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3, delay: 0.1 }}
            >
              <Card className="overflow-hidden border-none bg-background/60 backdrop-blur-lg shadow-md">
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Steps</CardTitle>
                  <Footprints className="h-4 w-4 text-blue-500" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">9,543</div>
                  <div className="flex items-center justify-between mt-1">
                    <p className="text-xs text-muted-foreground">Goal: 10,000</p>
                    <Badge variant="outline" className="text-xs font-normal h-5 px-1.5">
                      <ArrowUpRight className="mr-1 h-3 w-3 text-emerald-500" />
                      <span className="text-[10px]">12% vs. avg</span>
                    </Badge>
                  </div>
                  <Progress value={95.43} className="h-1.5 mt-2 bg-muted [&>div]:bg-blue-500" />
                </CardContent>
              </Card>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3, delay: 0.2 }}
            >
              <Card className="overflow-hidden border-none bg-background/60 backdrop-blur-lg shadow-md">
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Heart Rate</CardTitle>
                  <Heart className="h-4 w-4 text-rose-500" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">72 bpm</div>
                  <div className="flex items-center justify-between mt-1">
                    <p className="text-xs text-muted-foreground">Resting: 65 bpm</p>
                    <Badge variant="outline" className="text-xs font-normal h-5 px-1.5">
                      <ArrowDownRight className="mr-1 h-3 w-3 text-emerald-500" />
                      <span className="text-[10px]">3 bpm vs. avg</span>
                    </Badge>
                  </div>
                  <div className="h-1.5 w-full bg-muted mt-2 rounded-full overflow-hidden">
                    <div
                      className="h-full bg-gradient-to-r from-emerald-500 via-amber-500 to-rose-500"
                      style={{ width: "40%" }}
                    />
                  </div>
                </CardContent>
              </Card>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3, delay: 0.3 }}
            >
              <Card className="overflow-hidden border-none bg-background/60 backdrop-blur-lg shadow-md">
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Calories</CardTitle>
                  <Flame className="h-4 w-4 text-orange-500" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">650 kcal</div>
                  <div className="flex items-center justify-between mt-1">
                    <p className="text-xs text-muted-foreground">Goal: 700 kcal</p>
                    <Badge variant="outline" className="text-xs font-normal h-5 px-1.5">
                      <ArrowUpRight className="mr-1 h-3 w-3 text-emerald-500" />
                      <span className="text-[10px]">8% vs. avg</span>
                    </Badge>
                  </div>
                  <Progress value={92.8} className="h-1.5 mt-2 bg-muted [&>div]:bg-orange-500" />
                </CardContent>
              </Card>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3, delay: 0.4 }}
            >
              <Card className="overflow-hidden border-none bg-background/60 backdrop-blur-lg shadow-md">
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Sleep</CardTitle>
                  <Moon className="h-4 w-4 text-indigo-500" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">7.2 hrs</div>
                  <div className="flex items-center justify-between mt-1">
                    <p className="text-xs text-muted-foreground">Goal: 8 hrs</p>
                    <Badge variant="outline" className="text-xs font-normal h-5 px-1.5">
                      <ArrowDownRight className="mr-1 h-3 w-3 text-amber-500" />
                      <span className="text-[10px]">0.3 hrs vs. avg</span>
                    </Badge>
                  </div>
                  <div className="flex h-1.5 mt-2 rounded-full overflow-hidden">
                    <div className="bg-indigo-900 h-full" style={{ width: "25%" }} />
                    <div className="bg-indigo-500 h-full" style={{ width: "55%" }} />
                    <div className="bg-indigo-300 h-full" style={{ width: "20%" }} />
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          </div>

          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            <motion.div
              className="md:col-span-2"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3, delay: 0.5 }}
            >
              <Card className="overflow-hidden border-none bg-background/60 backdrop-blur-lg shadow-md">
                <CardHeader className="pb-2">
                  <CardTitle className="text-base">Daily Activity</CardTitle>
                  <CardDescription className="text-xs">Today's activity with real-time data</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="h-[300px]">
                    <ResponsiveContainer width="100%" height="100%">
                      {chartType === "area" ? (
                        <AreaChart data={getTimeRangeData()}>
                          <CartesianGrid strokeDasharray="3 3" opacity={0.2} />
                          <XAxis
                            dataKey={timeRange === "day" ? "time" : timeRange === "week" ? "day" : "week"}
                            tick={{ fontSize: 11 }}
                          />
                          <YAxis domain={[0, 12000]} tick={{ fontSize: 11 }} />
                          <Tooltip content={<CustomTooltip />} />
                          <Legend iconSize={8} wrapperStyle={{ fontSize: 11 }} />
                          <Area
                            type="monotone"
                            dataKey="steps"
                            name="Steps"
                            stroke="#3b82f6"
                            fill="#3b82f6"
                            fillOpacity={0.2}
                            unit=""
                          />
                          <ReferenceLine
                            y={10000}
                            label={{ value: "Goal", position: "insideTopRight", fontSize: 10 }}
                            stroke="#3b82f6"
                            strokeDasharray="3 3"
                          />
                        </AreaChart>
                      ) : chartType === "line" ? (
                        <ComposedChart data={getTimeRangeData()}>
                          <CartesianGrid strokeDasharray="3 3" opacity={0.2} />
                          <XAxis
                            dataKey={timeRange === "day" ? "time" : timeRange === "week" ? "day" : "week"}
                            tick={{ fontSize: 11 }}
                          />
                          <YAxis yAxisId="steps" domain={[0, 12000]} tick={{ fontSize: 11 }} />
                          <YAxis yAxisId="heartRate" orientation="right" domain={[50, 100]} tick={{ fontSize: 11 }} />
                          <Tooltip content={<CustomTooltip />} />
                          <Legend iconSize={8} wrapperStyle={{ fontSize: 11 }} />
                          <Line
                            yAxisId="steps"
                            type="monotone"
                            dataKey="steps"
                            name="Steps"
                            stroke="#3b82f6"
                            strokeWidth={2}
                            dot={{ r: 2 }}
                            unit=""
                          />
                          <Line
                            yAxisId="heartRate"
                            type="monotone"
                            dataKey="heartRate"
                            name="Heart Rate"
                            stroke="#ef4444"
                            strokeWidth={2}
                            dot={{ r: 2 }}
                            unit=" bpm"
                          />
                        </ComposedChart>
                      ) : (
                        <ComposedChart data={getTimeRangeData()}>
                          <CartesianGrid strokeDasharray="3 3" opacity={0.2} />
                          <XAxis
                            dataKey={timeRange === "day" ? "time" : timeRange === "week" ? "day" : "week"}
                            tick={{ fontSize: 11 }}
                          />
                          <YAxis yAxisId="steps" domain={[0, 12000]} tick={{ fontSize: 11 }} />
                          <YAxis yAxisId="heartRate" orientation="right" domain={[50, 100]} tick={{ fontSize: 11 }} />
                          <Tooltip content={<CustomTooltip />} />
                          <Legend iconSize={8} wrapperStyle={{ fontSize: 11 }} />
                          <Bar
                            yAxisId="steps"
                            dataKey="steps"
                            name="Steps"
                            fill="#3b82f6"
                            radius={[4, 4, 0, 0]}
                            unit=""
                          />
                          <Line
                            yAxisId="heartRate"
                            type="monotone"
                            dataKey="heartRate"
                            name="Heart Rate"
                            stroke="#ef4444"
                            strokeWidth={2}
                            dot={{ r: 2 }}
                            unit=" bpm"
                          />
                          <ReferenceLine
                            yAxisId="steps"
                            y={10000}
                            label={{ value: "Steps Goal", position: "insideTopRight", fontSize: 10 }}
                            stroke="#3b82f6"
                            strokeDasharray="3 3"
                          />
                          <ReferenceLine
                            yAxisId="heartRate"
                            y={65}
                            label={{ value: "Rest HR", position: "insideTopRight", fontSize: 10 }}
                            stroke="#ef4444"
                            strokeDasharray="3 3"
                          />
                        </ComposedChart>
                      )}
                    </ResponsiveContainer>
                  </div>
                </CardContent>
              </Card>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3, delay: 0.6 }}
            >
              <Card className="overflow-hidden border-none bg-background/60 backdrop-blur-lg shadow-md">
                <CardHeader className="pb-2">
                  <CardTitle className="text-base">Weekly Summary</CardTitle>
                  <CardDescription className="text-xs">Your health metrics for the week</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="h-[300px]">
                    <ResponsiveContainer width="100%" height="100%">
                      <ComposedChart data={weeklyData}>
                        <CartesianGrid strokeDasharray="3 3" opacity={0.2} />
                        <XAxis dataKey="day" tick={{ fontSize: 11 }} />
                        <YAxis yAxisId="steps" domain={[0, 15000]} hide />
                        <YAxis yAxisId="sleep" orientation="right" domain={[0, 10]} hide />
                        <Tooltip content={<CustomTooltip />} />
                        <Legend iconSize={8} wrapperStyle={{ fontSize: 11 }} />

                        {/* Steps bars */}
                        <Bar
                          yAxisId="steps"
                          dataKey="steps"
                          name="Steps"
                          fill="#3b82f6"
                          radius={[4, 4, 0, 0]}
                          unit=""
                        />

                        {/* Sleep line */}
                        <Line
                          yAxisId="sleep"
                          type="monotone"
                          dataKey="sleep"
                          name="Sleep"
                          stroke="#8b5cf6"
                          strokeWidth={2}
                          dot={{ r: 2 }}
                          unit=" hrs"
                        />

                        {/* Heart rate scatter */}
                        <Scatter yAxisId="sleep" dataKey="heartRate" name="Heart Rate" fill="#ef4444" unit=" bpm" />
                      </ComposedChart>
                    </ResponsiveContainer>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          </div>

          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
            <motion.div
              className="lg:col-span-2"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3, delay: 0.7 }}
            >
              <Card className="overflow-hidden border-none bg-background/60 backdrop-blur-lg shadow-md">
                <CardHeader className="pb-2">
                  <CardTitle className="text-base">Health Insights</CardTitle>
                  <CardDescription className="text-xs">Personalized recommendations based on your data</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-start gap-3 p-3 rounded-lg bg-blue-50 dark:bg-blue-950/30">
                      <div className="bg-blue-100 dark:bg-blue-900 p-1.5 rounded-full">
                        <Droplet className="h-4 w-4 text-blue-600 dark:text-blue-400" />
                      </div>
                      <div>
                        <h4 className="font-medium text-sm">Hydration Alert</h4>
                        <p className="text-xs text-muted-foreground mt-0.5">
                          You're 3 cups behind your water intake goal. Consider drinking more water in the afternoon.
                        </p>
                      </div>
                    </div>

                    <div className="flex items-start gap-3 p-3 rounded-lg bg-emerald-50 dark:bg-emerald-950/30">
                      <div className="bg-emerald-100 dark:bg-emerald-900 p-1.5 rounded-full">
                        <Activity className="h-4 w-4 text-emerald-600 dark:text-emerald-400" />
                      </div>
                      <div>
                        <h4 className="font-medium text-sm">Activity Trend</h4>
                        <p className="text-xs text-muted-foreground mt-0.5">
                          Your activity level has increased by 15% this week. Keep up the good work!
                        </p>
                      </div>
                    </div>

                    <div className="flex items-start gap-3 p-3 rounded-lg bg-indigo-50 dark:bg-indigo-950/30">
                      <div className="bg-indigo-100 dark:bg-indigo-900 p-1.5 rounded-full">
                        <Moon className="h-4 w-4 text-indigo-600 dark:text-indigo-400" />
                      </div>
                      <div>
                        <h4 className="font-medium text-sm">Sleep Suggestion</h4>
                        <p className="text-xs text-muted-foreground mt-0.5">
                          Your deep sleep has been decreasing. Try going to bed 30 minutes earlier tonight.
                        </p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>

            <motion.div
              className="lg:col-span-2"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3, delay: 0.8 }}
            >
              <Card className="overflow-hidden border-none bg-background/60 backdrop-blur-lg shadow-md">
                <CardHeader className="pb-2">
                  <CardTitle className="text-base">Vital Signs</CardTitle>
                  <CardDescription className="text-xs">Your current health metrics</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-1.5">
                          <Heart className="h-3.5 w-3.5 text-rose-500" />
                          <span className="text-xs">Heart Rate</span>
                        </div>
                        <span className="font-medium text-xs">72 bpm</span>
                      </div>
                      <Progress value={72} max={200} className="h-1.5 bg-muted [&>div]:bg-rose-500" />

                      <div className="flex items-center justify-between mt-3">
                        <div className="flex items-center gap-1.5">
                          <Waves className="h-3.5 w-3.5 text-blue-500" />
                          <span className="text-xs">Blood Pressure</span>
                        </div>
                        <span className="font-medium text-xs">118/78</span>
                      </div>
                      <Progress value={118} max={200} className="h-1.5 bg-muted [&>div]:bg-blue-500" />

                      <div className="flex items-center justify-between mt-3">
                        <div className="flex items-center gap-1.5">
                          <Thermometer className="h-3.5 w-3.5 text-orange-500" />
                          <span className="text-xs">Temperature</span>
                        </div>
                        <span className="font-medium text-xs">98.6°F</span>
                      </div>
                      <Progress value={98.6} min={95} max={105} className="h-1.5 bg-muted [&>div]:bg-orange-500" />
                    </div>

                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-1.5">
                          <Zap className="h-3.5 w-3.5 text-amber-500" />
                          <span className="text-xs">Stress Level</span>
                        </div>
                        <span className="font-medium text-xs">32/100</span>
                      </div>
                      <Progress value={32} max={100} className="h-1.5 bg-muted [&>div]:bg-amber-500" />

                      <div className="flex items-center justify-between mt-3">
                        <div className="flex items-center gap-1.5">
                          <Leaf className="h-3.5 w-3.5 text-emerald-500" />
                          <span className="text-xs">Oxygen Level</span>
                        </div>
                        <span className="font-medium text-xs">98%</span>
                      </div>
                      <Progress value={98} max={100} className="h-1.5 bg-muted [&>div]:bg-emerald-500" />

                      <div className="flex items-center justify-between mt-3">
                        <div className="flex items-center gap-1.5">
                          <Brain className="h-3.5 w-3.5 text-indigo-500" />
                          <span className="text-xs">Mindfulness</span>
                        </div>
                        <span className="font-medium text-xs">45 min</span>
                      </div>
                      <Progress value={45} max={60} className="h-1.5 bg-muted [&>div]:bg-indigo-500" />
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          </div>
        </div>
      )}

      {/* Activity Tab */}
      {activeTab === "activity" && (
        <div className="space-y-6">
          <div className="grid gap-4 md:grid-cols-3">
            <Card className="overflow-hidden border-none bg-background/60 backdrop-blur-lg shadow-md">
              <CardHeader className="pb-2">
                <CardTitle className="text-base">Activity Goals</CardTitle>
                <CardDescription className="text-xs">Your daily targets and progress</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="space-y-1.5">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-1.5">
                        <Footprints className="h-3.5 w-3.5 text-blue-500" />
                        <span className="text-sm">Steps</span>
                      </div>
                      <div className="font-medium text-xs">9,543 / 10,000</div>
                    </div>
                    <Progress value={95.43} className="h-1.5 bg-muted [&>div]:bg-blue-500" />
                  </div>

                  <div className="space-y-1.5">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-1.5">
                        <Activity className="h-3.5 w-3.5 text-emerald-500" />
                        <span className="text-sm">Distance</span>
                      </div>
                      <div className="font-medium text-xs">5.8 / 8.0 km</div>
                    </div>
                    <Progress value={72.5} className="h-1.5 bg-muted [&>div]:bg-emerald-500" />
                  </div>

                  <div className="space-y-1.5">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-1.5">
                        <Flame className="h-3.5 w-3.5 text-orange-500" />
                        <span className="text-sm">Calories</span>
                      </div>
                      <div className="font-medium text-xs">650 / 700 kcal</div>
                    </div>
                    <Progress value={92.8} className="h-1.5 bg-muted [&>div]:bg-orange-500" />
                  </div>

                  <div className="space-y-1.5">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-1.5">
                        <Dumbbell className="h-3.5 w-3.5 text-purple-500" />
                        <span className="text-sm">Active Minutes</span>
                      </div>
                      <div className="font-medium text-xs">45 / 60 min</div>
                    </div>
                    <Progress value={75} className="h-1.5 bg-muted [&>div]:bg-purple-500" />
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="overflow-hidden border-none bg-background/60 backdrop-blur-lg shadow-md md:col-span-2">
              <CardHeader className="pb-2">
                <CardTitle className="text-base">Weekly Activity Trends</CardTitle>
                <CardDescription className="text-xs">Your activity patterns over the past week</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-[300px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <ComposedChart data={weeklyData}>
                      <CartesianGrid strokeDasharray="3 3" opacity={0.2} />
                      <XAxis dataKey="day" tick={{ fontSize: 11 }} />
                      <YAxis yAxisId="steps" domain={[0, 15000]} tick={{ fontSize: 11 }} />
                      <YAxis yAxisId="calories" orientation="right" domain={[0, 600]} tick={{ fontSize: 11 }} />
                      <Tooltip content={<CustomTooltip />} />
                      <Legend iconSize={8} wrapperStyle={{ fontSize: 11 }} />

                      <Bar yAxisId="steps" dataKey="steps" name="Steps" fill="#3b82f6" radius={[4, 4, 0, 0]} unit="" />

                      <Line
                        yAxisId="calories"
                        type="monotone"
                        dataKey="calories"
                        name="Calories"
                        stroke="#ef4444"
                        strokeWidth={2}
                        dot={{ r: 2 }}
                        unit=" kcal"
                      />

                      <ReferenceLine
                        yAxisId="steps"
                        y={10000}
                        label={{ value: "Steps Goal", position: "insideTopRight", fontSize: 10 }}
                        stroke="#3b82f6"
                        strokeDasharray="3 3"
                      />

                      <ReferenceLine
                        yAxisId="calories"
                        y={400}
                        label={{ value: "Calorie Goal", position: "insideTopRight", fontSize: 10 }}
                        stroke="#ef4444"
                        strokeDasharray="3 3"
                      />
                    </ComposedChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="grid gap-4 md:grid-cols-2">
            <Card className="overflow-hidden border-none bg-background/60 backdrop-blur-lg shadow-md">
              <CardHeader className="pb-2">
                <CardTitle className="text-base">Heart Rate Zones</CardTitle>
                <CardDescription className="text-xs">Time spent in different heart rate zones</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-[300px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <AreaChart data={activityData} margin={{ top: 10, right: 30, left: 0, bottom: 0 }}>
                      <CartesianGrid strokeDasharray="3 3" opacity={0.2} />
                      <XAxis dataKey="time" tick={{ fontSize: 11 }} />
                      <YAxis domain={[50, 180]} tick={{ fontSize: 11 }} />
                      <Tooltip content={<CustomTooltip />} />
                      <defs>
                        <linearGradient id="heartRateGradient" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="5%" stopColor="#ef4444" stopOpacity={0.8} />
                          <stop offset="95%" stopColor="#ef4444" stopOpacity={0.2} />
                        </linearGradient>
                      </defs>
                      <Area
                        type="monotone"
                        dataKey="heartRate"
                        stroke="#ef4444"
                        fill="url(#heartRateGradient)"
                        name="Heart Rate"
                        unit=" bpm"
                      />
                      <ReferenceLine
                        y={65}
                        label={{ value: "Rest", position: "insideTopRight", fontSize: 10 }}
                        stroke="#ef4444"
                        strokeDasharray="3 3"
                      />
                      <ReferenceLine
                        y={120}
                        label={{ value: "Moderate", position: "insideTopRight", fontSize: 10 }}
                        stroke="#f97316"
                        strokeDasharray="3 3"
                      />
                      <ReferenceLine
                        y={150}
                        label={{ value: "Intense", position: "insideTopRight", fontSize: 10 }}
                        stroke="#dc2626"
                        strokeDasharray="3 3"
                      />
                    </AreaChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>

            <Card className="overflow-hidden border-none bg-background/60 backdrop-blur-lg shadow-md">
              <CardHeader className="pb-2">
                <CardTitle className="text-base">Recent Workouts</CardTitle>
                <CardDescription className="text-xs">Your latest exercise sessions</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {workoutData.map((workout, index) => (
                    <div
                      key={index}
                      className="flex items-center justify-between p-2.5 border rounded-lg bg-background/40"
                    >
                      <div className="flex items-center gap-2.5">
                        <div className="bg-primary/10 p-1.5 rounded-full">
                          <Dumbbell className="h-4 w-4 text-primary" />
                        </div>
                        <div>
                          <div className="font-medium text-sm">{workout.name}</div>
                          <div className="text-xs text-muted-foreground">
                            {workout.duration} min • {workout.calories} kcal
                          </div>
                        </div>
                      </div>
                      <div className="flex items-center gap-1.5">
                        <Heart className="h-3.5 w-3.5 text-rose-500" />
                        <span className="text-xs">{workout.heartRate} bpm</span>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      )}

      {/* Sleep Tab */}
      {activeTab === "sleep" && (
        <div className="space-y-6">
          <div className="grid gap-4 md:grid-cols-3">
            <Card className="overflow-hidden border-none bg-background/60 backdrop-blur-lg shadow-md">
              <CardHeader className="pb-2">
                <CardTitle className="text-base">Sleep Summary</CardTitle>
                <CardDescription className="text-xs">Last night's sleep quality</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex flex-col items-center justify-center">
                  <div className="relative w-36 h-36 mb-3">
                    <svg className="w-full h-full" viewBox="0 0 100 100">
                      <circle
                        className="text-muted stroke-current"
                        strokeWidth="10"
                        fill="transparent"
                        r="45"
                        cx="50"
                        cy="50"
                      />
                      <circle
                        className="text-indigo-500 stroke-current"
                        strokeWidth="10"
                        strokeLinecap="round"
                        fill="transparent"
                        r="45"
                        cx="50"
                        cy="50"
                        strokeDasharray={2 * Math.PI * 40}
                        strokeDashoffset={2 * Math.PI * 40 * (1 - 7.2 / 8)}
                        transform="rotate(-90 50 50)"
                      />
                      <text
                        x="50"
                        y="50"
                        textAnchor="middle"
                        dominantBaseline="middle"
                        className="text-3xl font-bold"
                        fill="currentColor"
                      >
                        7.2h
                      </text>
                    </svg>
                  </div>

                  <div className="grid grid-cols-4 w-full gap-2 text-center">
                    <div className="flex flex-col items-center">
                      <div className="text-xs text-muted-foreground">Deep</div>
                      <div className="font-medium text-sm">2.1h</div>
                      <div className="w-full h-1 bg-indigo-900 rounded-full mt-1" />
                    </div>
                    <div className="flex flex-col items-center">
                      <div className="text-xs text-muted-foreground">Light</div>
                      <div className="font-medium text-sm">4.2h</div>
                      <div className="w-full h-1 bg-indigo-500 rounded-full mt-1" />
                    </div>
                    <div className="flex flex-col items-center">
                      <div className="text-xs text-muted-foreground">REM</div>
                      <div className="font-medium text-sm">1.5h</div>
                      <div className="w-full h-1 bg-indigo-300 rounded-full mt-1" />
                    </div>
                    <div className="flex flex-col items-center">
                      <div className="text-xs text-muted-foreground">Awake</div>
                      <div className="font-medium text-sm">0.3h</div>
                      <div className="w-full h-1 bg-gray-400 rounded-full mt-1" />
                    </div>
                  </div>

                  <div className="mt-3 text-center">
                    <div className="text-xs font-medium">Sleep Score</div>
                    <div className="text-xl font-bold">82/100</div>
                    <Badge className="mt-1 text-xs h-5 px-2">Good</Badge>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="overflow-hidden border-none bg-background/60 backdrop-blur-lg shadow-md md:col-span-2">
              <CardHeader className="pb-2">
                <CardTitle className="text-base">Weekly Sleep Pattern</CardTitle>
                <CardDescription className="text-xs">Your sleep composition over the past week</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-[300px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <AreaChart
                      data={sleepData}
                      margin={{ top: 10, right: 30, left: 0, bottom: 0 }}
                      stackOffset="expand"
                    >
                      <CartesianGrid strokeDasharray="3 3" opacity={0.2} />
                      <XAxis dataKey="day" tick={{ fontSize: 11 }} />
                      <YAxis tickFormatter={(value) => `${(value * 100).toFixed(0)}%`} tick={{ fontSize: 11 }} />
                      <Tooltip content={<CustomTooltip />} />
                      <Legend iconSize={8} wrapperStyle={{ fontSize: 11 }} />
                      <Area
                        type="monotone"
                        dataKey="deep"
                        stackId="1"
                        stroke="#1e3a8a"
                        fill="#1e3a8a"
                        name="Deep Sleep"
                        unit=" hrs"
                      />
                      <Area
                        type="monotone"
                        dataKey="light"
                        stackId="1"
                        stroke="#3b82f6"
                        fill="#3b82f6"
                        name="Light Sleep"
                        unit=" hrs"
                      />
                      <Area
                        type="monotone"
                        dataKey="rem"
                        stackId="1"
                        stroke="#93c5fd"
                        fill="#93c5fd"
                        name="REM Sleep"
                        unit=" hrs"
                      />
                      <Area
                        type="monotone"
                        dataKey="awake"
                        stackId="1"
                        stroke="#9ca3af"
                        fill="#9ca3af"
                        name="Awake"
                        unit=" hrs"
                      />
                    </AreaChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="grid gap-4 md:grid-cols-2">
            <Card className="overflow-hidden border-none bg-background/60 backdrop-blur-lg shadow-md">
              <CardHeader className="pb-2">
                <CardTitle className="text-base">Sleep Insights</CardTitle>
                <CardDescription className="text-xs">Personalized sleep recommendations</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex items-start gap-3 p-3 rounded-lg bg-indigo-50 dark:bg-indigo-950/30">
                    <div className="bg-indigo-100 dark:bg-indigo-900 p-1.5 rounded-full">
                      <Moon className="h-4 w-4 text-indigo-600 dark:text-indigo-400" />
                    </div>
                    <div>
                      <h4 className="font-medium text-sm">Sleep Consistency</h4>
                      <p className="text-xs text-muted-foreground mt-0.5">
                        Your sleep schedule varies by more than 1 hour on weekends. Try to maintain a consistent sleep
                        schedule.
                      </p>
                    </div>
                  </div>

                  <div className="flex items-start gap-3 p-3 rounded-lg bg-purple-50 dark:bg-purple-950/30">
                    <div className="bg-purple-100 dark:bg-purple-900 p-1.5 rounded-full">
                      <Zap className="h-4 w-4 text-purple-600 dark:text-purple-400" />
                    </div>
                    <div>
                      <h4 className="font-medium text-sm">Deep Sleep</h4>
                      <p className="text-xs text-muted-foreground mt-0.5">
                        Your deep sleep has decreased by 15% this week. Consider reducing screen time before bed.
                      </p>
                    </div>
                  </div>

                  <div className="flex items-start gap-3 p-3 rounded-lg bg-emerald-50 dark:bg-emerald-950/30">
                    <div className="bg-emerald-100 dark:bg-emerald-900 p-1.5 rounded-full">
                      <Activity className="h-4 w-4 text-emerald-600 dark:text-emerald-400" />
                    </div>
                    <div>
                      <h4 className="font-medium text-sm">Activity Impact</h4>
                      <p className="text-xs text-muted-foreground mt-0.5">
                        Days with 8,000+ steps show 12% better sleep quality. Keep up your daily activity.
                      </p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="overflow-hidden border-none bg-background/60 backdrop-blur-lg shadow-md">
              <CardHeader className="pb-2">
                <CardTitle className="text-base">Sleep Factors</CardTitle>
                <CardDescription className="text-xs">Elements affecting your sleep quality</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="space-y-1.5">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-1.5">
                        <Thermometer className="h-3.5 w-3.5 text-orange-500" />
                        <span className="text-sm">Bedroom Temperature</span>
                      </div>
                      <div className="font-medium text-xs">68°F</div>
                    </div>
                    <Progress value={80} className="h-1.5 bg-muted [&>div]:bg-emerald-500" />
                    <div className="text-[10px] text-right text-muted-foreground">Optimal</div>
                  </div>

                  <div className="space-y-1.5">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-1.5">
                        <Utensils className="h-3.5 w-3.5 text-amber-500" />
                        <span className="text-sm">Evening Meal Time</span>
                      </div>
                      <div className="font-medium text-xs">7:30 PM</div>
                    </div>
                    <Progress value={70} className="h-1.5 bg-muted [&>div]:bg-emerald-500" />
                    <div className="text-[10px] text-right text-muted-foreground">Good</div>
                  </div>

                  <div className="space-y-1.5">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-1.5">
                        <Smartphone className="h-3.5 w-3.5 text-blue-500" />
                        <span className="text-sm">Screen Time Before Bed</span>
                      </div>
                      <div className="font-medium text-xs">45 min</div>
                    </div>
                    <Progress value={40} className="h-1.5 bg-muted [&>div]:bg-amber-500" />
                    <div className="text-[10px] text-right text-muted-foreground">Needs Improvement</div>
                  </div>

                  <div className="space-y-1.5">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-1.5">
                        <Brain className="h-3.5 w-3.5 text-purple-500" />
                        <span className="text-sm">Stress Level</span>
                      </div>
                      <div className="font-medium text-xs">Medium</div>
                    </div>
                    <Progress value={50} className="h-1.5 bg-muted [&>div]:bg-amber-500" />
                    <div className="text-[10px] text-right text-muted-foreground">Moderate Impact</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      )}

      {/* Nutrition Tab */}
      {activeTab === "nutrition" && (
        <div className="space-y-6">
          <div className="grid gap-4 md:grid-cols-3">
            <Card className="overflow-hidden border-none bg-background/60 backdrop-blur-lg shadow-md">
              <CardHeader className="pb-2">
                <CardTitle className="text-base">Calorie Summary</CardTitle>
                <CardDescription className="text-xs">Today's calorie intake and burn</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex flex-col items-center justify-center">
                  <div className="relative w-36 h-36 mb-3">
                    <svg className="w-full h-full" viewBox="0 0 100 100">
                      <circle
                        className="text-muted stroke-current"
                        strokeWidth="10"
                        fill="transparent"
                        r="45"
                        cx="50"
                        cy="50"
                      />
                      <circle
                        className="text-amber-500 stroke-current"
                        strokeWidth="10"
                        strokeLinecap="round"
                        fill="transparent"
                        r="45"
                        cx="50"
                        cy="50"
                        strokeDasharray={2 * Math.PI * 40}
                        strokeDashoffset={
                          2 * Math.PI * 40 * (1 - nutritionData.calories.consumed / nutritionData.calories.goal)
                        }
                        transform="rotate(-90 50 50)"
                      />
                      <text
                        x="50"
                        y="45"
                        textAnchor="middle"
                        dominantBaseline="middle"
                        className="text-xl font-bold"
                        fill="currentColor"
                      >
                        {nutritionData.calories.consumed}
                      </text>
                      <text
                        x="50"
                        y="65"
                        textAnchor="middle"
                        dominantBaseline="middle"
                        className="text-xs"
                        fill="currentColor"
                      >
                        of {nutritionData.calories.goal} kcal
                      </text>
                    </svg>
                  </div>

                  <div className="grid grid-cols-2 w-full gap-3 text-center">
                    <div className="p-2.5 rounded-lg bg-emerald-50 dark:bg-emerald-900/20">
                      <div className="text-xs text-muted-foreground">Consumed</div>
                      <div className="text-lg font-bold">{nutritionData.calories.consumed}</div>
                      <div className="text-[10px] text-muted-foreground">calories</div>
                    </div>
                    <div className="p-2.5 rounded-lg bg-blue-50 dark:bg-blue-900/20">
                      <div className="text-xs text-muted-foreground">Burned</div>
                      <div className="text-lg font-bold">650</div>
                      <div className="text-[10px] text-muted-foreground">calories</div>
                    </div>
                  </div>

                  <div className="mt-3 text-center">
                    <div className="text-xs font-medium">Net Calories</div>
                    <div className="text-xl font-bold">{nutritionData.calories.consumed - 650}</div>
                    <Badge variant="outline" className="mt-1 text-xs h-5 px-1.5">
                      <ArrowDownRight className="mr-1 h-3 w-3 text-emerald-500" />
                      <span className="text-[10px]">350 below goal</span>
                    </Badge>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="overflow-hidden border-none bg-background/60 backdrop-blur-lg shadow-md md:col-span-2">
              <CardHeader className="pb-2">
                <CardTitle className="text-base">Macronutrient Distribution</CardTitle>
                <CardDescription className="text-xs">Your macronutrient intake breakdown</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid md:grid-cols-2 gap-4">
                  <div className="space-y-3">
                    <div className="space-y-1.5">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-1.5">
                          <div className="h-2.5 w-2.5 rounded-full bg-rose-500" />
                          <span className="text-sm">Protein</span>
                        </div>
                        <div className="font-medium text-xs">
                          {nutritionData.protein.consumed}g / {nutritionData.protein.goal}g
                        </div>
                      </div>
                      <Progress
                        value={(nutritionData.protein.consumed / nutritionData.protein.goal) * 100}
                        className="h-1.5 bg-muted [&>div]:bg-rose-500"
                      />
                    </div>

                    <div className="space-y-1.5">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-1.5">
                          <div className="h-2.5 w-2.5 rounded-full bg-blue-500" />
                          <span className="text-sm">Carbs</span>
                        </div>
                        <div className="font-medium text-xs">
                          {nutritionData.carbs.consumed}g / {nutritionData.carbs.goal}g
                        </div>
                      </div>
                      <Progress
                        value={(nutritionData.carbs.consumed / nutritionData.carbs.goal) * 100}
                        className="h-1.5 bg-muted [&>div]:bg-blue-500"
                      />
                    </div>

                    <div className="space-y-1.5">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-1.5">
                          <div className="h-2.5 w-2.5 rounded-full bg-amber-500" />
                          <span className="text-sm">Fat</span>
                        </div>
                        <div className="font-medium text-xs">
                          {nutritionData.fat.consumed}g / {nutritionData.fat.goal}g
                        </div>
                      </div>
                      <Progress
                        value={(nutritionData.fat.consumed / nutritionData.fat.goal) * 100}
                        className="h-1.5 bg-muted [&>div]:bg-amber-500"
                      />
                    </div>

                    <div className="space-y-1.5">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-1.5">
                          <div className="h-2.5 w-2.5 rounded-full bg-cyan-500" />
                          <span className="text-sm">Water</span>
                        </div>
                        <div className="font-medium text-xs">
                          {nutritionData.water.consumed} / {nutritionData.water.goal} cups
                        </div>
                      </div>
                      <Progress
                        value={(nutritionData.water.consumed / nutritionData.water.goal) * 100}
                        className="h-1.5 bg-muted [&>div]:bg-cyan-500"
                      />
                    </div>
                  </div>

                  <div className="h-[300px]">
                    <ResponsiveContainer width="100%" height="100%">
                      <ComposedChart
                        data={[
                          {
                            name: "Protein",
                            actual: nutritionData.protein.consumed,
                            goal: nutritionData.protein.goal,
                            percent: (nutritionData.protein.consumed / nutritionData.protein.goal) * 100,
                          },
                          {
                            name: "Carbs",
                            actual: nutritionData.carbs.consumed,
                            goal: nutritionData.carbs.goal,
                            percent: (nutritionData.carbs.consumed / nutritionData.carbs.goal) * 100,
                          },
                          {
                            name: "Fat",
                            actual: nutritionData.fat.consumed,
                            goal: nutritionData.fat.goal,
                            percent: (nutritionData.fat.consumed / nutritionData.fat.goal) * 100,
                          },
                        ]}
                      >
                        <CartesianGrid strokeDasharray="3 3" opacity={0.2} />
                        <XAxis dataKey="name" tick={{ fontSize: 11 }} />
                        <YAxis yAxisId="left" orientation="left" domain={[0, 300]} tick={{ fontSize: 11 }} />
                        <YAxis yAxisId="right" orientation="right" domain={[0, 100]} tick={{ fontSize: 11 }} />
                        <Tooltip content={<CustomTooltip />} />
                        <Legend iconSize={8} wrapperStyle={{ fontSize: 11 }} />
                        <Bar yAxisId="left" dataKey="actual" name="Actual (g)" fill="#3b82f6" radius={[4, 4, 0, 0]} />
                        <Bar yAxisId="left" dataKey="goal" name="Goal (g)" fill="#9ca3af" radius={[4, 4, 0, 0]} />
                        <Line
                          yAxisId="right"
                          type="monotone"
                          dataKey="percent"
                          name="% of Goal"
                          stroke="#10b981"
                          strokeWidth={2}
                          dot={{ r: 2 }}
                          unit="%"
                        />
                      </ComposedChart>
                    </ResponsiveContainer>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="grid gap-4 md:grid-cols-2">
            <Card className="overflow-hidden border-none bg-background/60 backdrop-blur-lg shadow-md">
              <CardHeader className="pb-2">
                <CardTitle className="text-base">Meal Log</CardTitle>
                <CardDescription className="text-xs">Today's food intake</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="p-2.5 rounded-lg border bg-background/40">
                    <div className="flex items-center justify-between mb-1.5">
                      <div className="font-medium text-sm">Breakfast</div>
                      <Badge variant="outline" className="text-xs h-5 px-1.5">
                        450 kcal
                      </Badge>
                    </div>
                    <div className="text-xs text-muted-foreground">Oatmeal with berries, banana, and almond milk</div>
                    <div className="flex items-center gap-2.5 mt-1.5 text-[10px]">
                      <div className="flex items-center gap-1">
                        <div className="h-2 w-2 rounded-full bg-rose-500" />
                        <span>15g protein</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <div className="h-2 w-2 rounded-full bg-blue-500" />
                        <span>65g carbs</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <div className="h-2 w-2 rounded-full bg-amber-500" />
                        <span>12g fat</span>
                      </div>
                    </div>
                  </div>

                  <div className="p-2.5 rounded-lg border bg-background/40">
                    <div className="flex items-center justify-between mb-1.5">
                      <div className="font-medium text-sm">Lunch</div>
                      <Badge variant="outline" className="text-xs h-5 px-1.5">
                        650 kcal
                      </Badge>
                    </div>
                    <div className="text-xs text-muted-foreground">
                      Grilled chicken salad with mixed vegetables and olive oil dressing
                    </div>
                    <div className="flex items-center gap-2.5 mt-1.5 text-[10px]">
                      <div className="flex items-center gap-1">
                        <div className="h-2 w-2 rounded-full bg-rose-500" />
                        <span>35g protein</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <div className="h-2 w-2 rounded-full bg-blue-500" />
                        <span>45g carbs</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <div className="h-2 w-2 rounded-full bg-amber-500" />
                        <span>28g fat</span>
                      </div>
                    </div>
                  </div>

                  <div className="p-2.5 rounded-lg border bg-background/40">
                    <div className="flex items-center justify-between mb-1.5">
                      <div className="font-medium text-sm">Snack</div>
                      <Badge variant="outline" className="text-xs h-5 px-1.5">
                        220 kcal
                      </Badge>
                    </div>
                    <div className="text-xs text-muted-foreground">Greek yogurt with honey and mixed nuts</div>
                    <div className="flex items-center gap-2.5 mt-1.5 text-[10px]">
                      <div className="flex items-center gap-1">
                        <div className="h-2 w-2 rounded-full bg-rose-500" />
                        <span>15g protein</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <div className="h-2 w-2 rounded-full bg-blue-500" />
                        <span>20g carbs</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <div className="h-2 w-2 rounded-full bg-amber-500" />
                        <span>10g fat</span>
                      </div>
                    </div>
                  </div>

                  <div className="p-2.5 rounded-lg border bg-background/40">
                    <div className="flex items-center justify-between mb-1.5">
                      <div className="font-medium text-sm">Dinner</div>
                      <Badge variant="outline" className="text-xs h-5 px-1.5">
                        530 kcal
                      </Badge>
                    </div>
                    <div className="text-xs text-muted-foreground">Salmon with quinoa and steamed vegetables</div>
                    <div className="flex items-center gap-2.5 mt-1.5 text-[10px]">
                      <div className="flex items-center gap-1">
                        <div className="h-2 w-2 rounded-full bg-rose-500" />
                        <span>30g protein</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <div className="h-2 w-2 rounded-full bg-blue-500" />
                        <span>45g carbs</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <div className="h-2 w-2 rounded-full bg-amber-500" />
                        <span>15g fat</span>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="overflow-hidden border-none bg-background/60 backdrop-blur-lg shadow-md">
              <CardHeader className="pb-2">
                <CardTitle className="text-base">Nutrition Insights</CardTitle>
                <CardDescription className="text-xs">Personalized nutrition recommendations</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex items-start gap-3 p-3 rounded-lg bg-emerald-50 dark:bg-emerald-950/30">
                    <div className="bg-emerald-100 dark:bg-emerald-900 p-1.5 rounded-full">
                      <Leaf className="h-4 w-4 text-emerald-600 dark:text-emerald-400" />
                    </div>
                    <div>
                      <h4 className="font-medium text-sm">Protein Intake</h4>
                      <p className="text-xs text-muted-foreground mt-0.5">
                        You're consistently meeting your protein goals. Great job maintaining muscle health!
                      </p>
                    </div>
                  </div>

                  <div className="flex items-start gap-3 p-3 rounded-lg bg-amber-50 dark:bg-amber-950/30">
                    <div className="bg-amber-100 dark:bg-amber-900 p-1.5 rounded-full">
                      <Droplet className="h-4 w-4 text-amber-600 dark:text-amber-400" />
                    </div>
                    <div>
                      <h4 className="font-medium text-sm">Hydration</h4>
                      <p className="text-xs text-muted-foreground mt-0.5">
                        You're 3 cups below your water intake goal. Try setting reminders to drink water throughout the
                        day.
                      </p>
                    </div>
                  </div>

                  <div className="flex items-start gap-3 p-3 rounded-lg bg-blue-50 dark:bg-blue-950/30">
                    <div className="bg-blue-100 dark:bg-blue-900 p-1.5 rounded-full">
                      <Utensils className="h-4 w-4 text-blue-600 dark:text-blue-400" />
                    </div>
                    <div>
                      <h4 className="font-medium text-sm">Meal Timing</h4>
                      <p className="text-xs text-muted-foreground mt-0.5">
                        Your meal spacing is optimal for energy levels. Continue eating every 3-4 hours for stable blood
                        sugar.
                      </p>
                    </div>
                  </div>

                  <div className="flex items-start gap-3 p-3 rounded-lg bg-purple-50 dark:bg-purple-950/30">
                    <div className="bg-purple-100 dark:bg-purple-900 p-1.5 rounded-full">
                      <Activity className="h-4 w-4 text-purple-600 dark:text-purple-400" />
                    </div>
                    <div>
                      <h4 className="font-medium text-sm">Nutrient Timing</h4>
                      <p className="text-xs text-muted-foreground mt-0.5">
                        Consider adding a small protein-rich snack after your workouts to optimize recovery.
                      </p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      )}
    </div>
  )
}
