"use client"

import { useState } from "react"
import { ModeToggle } from "@/components/mode-toggle"
import { MoodTracker } from "@/components/mood-tracker"
import { WaterIntakeTracker } from "@/components/water-intake-tracker"
import { BreathingAnimation } from "@/components/breathing-animation"
import { MealLogger } from "@/components/meal-logger"
import { SleepTracker } from "@/components/sleep-tracker"
import { FitnessRoutine } from "@/components/fitness-routine"
import { StretchSequence } from "@/components/stretch-sequence"
import { MentalHealthJournal } from "@/components/mental-health-journal"
import { WeightTracker } from "@/components/weight-tracker"
import { HealthDashboard } from "@/components/health-dashboard"
import { ParticleBackground } from "@/components/particle-background"
import { Button } from "@/components/ui/button"
import {
  Home,
  SmilePlus,
  Droplets,
  Wind,
  Utensils,
  Moon,
  Dumbbell,
  SpaceIcon as Yoga,
  Brain,
  Weight,
  Menu,
} from "lucide-react"
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"
import { useIsMobile } from "@/hooks/use-mobile"

export function MainDashboard() {
  const [activeTab, setActiveTab] = useState("dashboard")
  const isMobile = useIsMobile()

  const tabs = [
    { id: "dashboard", label: "Dashboard", icon: <Home className="h-5 w-5" /> },
    { id: "mood", label: "Mood", icon: <SmilePlus className="h-5 w-5" /> },
    { id: "water", label: "Water", icon: <Droplets className="h-5 w-5" /> },
    { id: "breathing", label: "Breathing", icon: <Wind className="h-5 w-5" /> },
    { id: "meals", label: "Meals", icon: <Utensils className="h-5 w-5" /> },
    { id: "sleep", label: "Sleep", icon: <Moon className="h-5 w-5" /> },
    { id: "fitness", label: "Fitness", icon: <Dumbbell className="h-5 w-5" /> },
    { id: "stretch", label: "Stretch", icon: <Yoga className="h-5 w-5" /> },
    { id: "journal", label: "Journal", icon: <Brain className="h-5 w-5" /> },
    { id: "weight", label: "Weight", icon: <Weight className="h-5 w-5" /> },
  ]

  const renderTabContent = (id: string) => {
    switch (id) {
      case "dashboard":
        return <HealthDashboard />
      case "mood":
        return <MoodTracker />
      case "water":
        return <WaterIntakeTracker />
      case "breathing":
        return <BreathingAnimation />
      case "meals":
        return <MealLogger />
      case "sleep":
        return <SleepTracker />
      case "fitness":
        return <FitnessRoutine />
      case "stretch":
        return <StretchSequence />
      case "journal":
        return <MentalHealthJournal />
      case "weight":
        return <WeightTracker />
      default:
        return <HealthDashboard />
    }
  }

  return (
    <div className="min-h-screen bg-background relative overflow-hidden">
      <ParticleBackground />

      <div className="container mx-auto p-4 relative z-10">
        <header className="flex justify-between items-center py-6">
          <div className="flex items-center gap-2">
            <div className="h-8 w-8 rounded-full bg-gradient-to-br from-green-400 to-emerald-600 flex items-center justify-center">
              <span className="text-white text-lg">🌿</span>
            </div>
            <h1 className="text-2xl font-bold bg-gradient-to-r from-green-500 to-emerald-700 dark:from-green-400 dark:to-emerald-600 bg-clip-text text-transparent">
              Wellness Daily
            </h1>
          </div>

          <div className="flex items-center gap-2">
            <ModeToggle />
            {isMobile && (
              <Sheet>
                <SheetTrigger asChild>
                  <Button variant="outline" size="icon">
                    <Menu className="h-5 w-5" />
                  </Button>
                </SheetTrigger>
                <SheetContent side="left" className="w-[250px] sm:w-[300px]">
                  <div className="py-4">
                    <h2 className="text-lg font-semibold mb-4">Navigation</h2>
                    <div className="space-y-2">
                      {tabs.map((tab) => (
                        <Button
                          key={tab.id}
                          variant={activeTab === tab.id ? "default" : "ghost"}
                          className="w-full justify-start"
                          onClick={() => {
                            setActiveTab(tab.id)
                          }}
                        >
                          {tab.icon}
                          <span className="ml-2">{tab.label}</span>
                        </Button>
                      ))}
                    </div>
                  </div>
                </SheetContent>
              </Sheet>
            )}
          </div>
        </header>

        {!isMobile && (
          <div className="mt-6 flex flex-wrap gap-2 justify-center">
            {tabs.map((tab) => (
              <Button
                key={tab.id}
                variant={activeTab === tab.id ? "default" : "outline"}
                className="flex items-center gap-2"
                onClick={() => setActiveTab(tab.id)}
              >
                {tab.icon}
                <span className="hidden md:inline">{tab.label}</span>
              </Button>
            ))}
          </div>
        )}

        <main className="mt-6 pb-20">{renderTabContent(activeTab)}</main>

        <footer className="text-center text-sm text-muted-foreground py-6">
          <p>© 2025 Wellness Daily. All rights reserved.</p>
        </footer>
      </div>
    </div>
  )
}
