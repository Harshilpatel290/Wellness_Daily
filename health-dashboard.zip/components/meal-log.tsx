"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Trash2, Plus } from "lucide-react"
import { Progress } from "@/components/ui/progress"

interface Meal {
  id: string
  name: string
  calories: number
  time: string
}

export default function MealLog() {
  const [meals, setMeals] = useState<Meal[]>([
    { id: "1", name: "Breakfast - Oatmeal with fruit", calories: 350, time: "08:00" },
    { id: "2", name: "Lunch - Chicken salad", calories: 450, time: "12:30" },
    { id: "3", name: "Snack - Protein bar", calories: 200, time: "15:00" },
  ])

  const [newMeal, setNewMeal] = useState<Omit<Meal, "id">>({
    name: "",
    calories: 0,
    time: "",
  })

  const [calorieGoal, setCalorieGoal] = useState(2000)

  const handleAddMeal = () => {
    if (newMeal.name && newMeal.calories > 0) {
      setMeals([
        ...meals,
        {
          id: Date.now().toString(),
          ...newMeal,
        },
      ])
      setNewMeal({
        name: "",
        calories: 0,
        time: "",
      })
    }
  }

  const handleDeleteMeal = (id: string) => {
    setMeals(meals.filter((meal) => meal.id !== id))
  }

  const totalCalories = meals.reduce((sum, meal) => sum + meal.calories, 0)
  const caloriesRemaining = calorieGoal - totalCalories
  const progressPercentage = Math.min(100, (totalCalories / calorieGoal) * 100)

  return (
    <div className="grid gap-6 md:grid-cols-2">
      <Card>
        <CardHeader>
          <CardTitle>Meal Log</CardTitle>
          <CardDescription>Track your daily food intake</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4 mb-6">
            <div className="grid grid-cols-3 gap-4">
              <div className="col-span-3 md:col-span-1">
                <div className="text-center p-4 bg-muted rounded-lg">
                  <div className="text-sm text-muted-foreground">Goal</div>
                  <div className="text-2xl font-bold">{calorieGoal}</div>
                  <div className="text-xs text-muted-foreground">calories</div>
                </div>
              </div>
              <div className="col-span-3 md:col-span-1">
                <div className="text-center p-4 bg-muted rounded-lg">
                  <div className="text-sm text-muted-foreground">Consumed</div>
                  <div className="text-2xl font-bold">{totalCalories}</div>
                  <div className="text-xs text-muted-foreground">calories</div>
                </div>
              </div>
              <div className="col-span-3 md:col-span-1">
                <div className="text-center p-4 bg-muted rounded-lg">
                  <div className="text-sm text-muted-foreground">Remaining</div>
                  <div className={`text-2xl font-bold ${caloriesRemaining < 0 ? "text-red-500" : ""}`}>
                    {caloriesRemaining}
                  </div>
                  <div className="text-xs text-muted-foreground">calories</div>
                </div>
              </div>
            </div>

            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span>Daily Progress</span>
                <span>
                  {totalCalories} / {calorieGoal} calories
                </span>
              </div>
              <Progress value={progressPercentage} className="h-3" />
            </div>
          </div>

          <div className="space-y-4">
            <div className="grid gap-2">
              <Label htmlFor="meal-name">Meal Name</Label>
              <Input
                id="meal-name"
                placeholder="Enter meal name"
                value={newMeal.name}
                onChange={(e) => setNewMeal({ ...newMeal, name: e.target.value })}
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="grid gap-2">
                <Label htmlFor="calories">Calories</Label>
                <Input
                  id="calories"
                  type="number"
                  placeholder="0"
                  value={newMeal.calories || ""}
                  onChange={(e) => setNewMeal({ ...newMeal, calories: Number.parseInt(e.target.value) || 0 })}
                />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="time">Time</Label>
                <Input
                  id="time"
                  type="time"
                  value={newMeal.time}
                  onChange={(e) => setNewMeal({ ...newMeal, time: e.target.value })}
                />
              </div>
            </div>

            <Button className="w-full" onClick={handleAddMeal} disabled={!newMeal.name || newMeal.calories <= 0}>
              <Plus className="mr-2 h-4 w-4" /> Add Meal
            </Button>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Today's Meals</CardTitle>
          <CardDescription>Your food intake for the day</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {meals.length === 0 ? (
              <div className="text-center py-6 text-muted-foreground">No meals logged today</div>
            ) : (
              meals.map((meal) => (
                <div key={meal.id} className="flex items-center justify-between p-3 border rounded-lg">
                  <div>
                    <div className="font-medium">{meal.name}</div>
                    <div className="text-sm text-muted-foreground">{meal.time}</div>
                  </div>
                  <div className="flex items-center gap-4">
                    <div className="text-sm font-medium">{meal.calories} cal</div>
                    <Button variant="ghost" size="icon" onClick={() => handleDeleteMeal(meal.id)}>
                      <Trash2 className="h-4 w-4 text-muted-foreground" />
                    </Button>
                  </div>
                </div>
              ))
            )}
          </div>
        </CardContent>
        <CardFooter className="flex justify-between border-t px-6 py-4">
          <div className="text-sm text-muted-foreground">Total Meals: {meals.length}</div>
          <div className="font-medium">Total: {totalCalories} calories</div>
        </CardFooter>
      </Card>
    </div>
  )
}
