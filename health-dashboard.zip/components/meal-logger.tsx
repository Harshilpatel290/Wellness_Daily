"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Trash2, Plus } from "lucide-react"
import { Progress } from "@/components/ui/progress"
import { motion, AnimatePresence } from "framer-motion"

interface Meal {
  id: string
  name: string
  calories: number
  time: string
}

export function MealLogger() {
  const [meals, setMeals] = useState<Meal[]>([
    { id: "1", name: "Breakfast - Oatmeal with fruit", calories: 350, time: "08:00" },
    { id: "2", name: "Lunch - Chicken salad", calories: 450, time: "12:30" },
    { id: "3", name: "Snack - Protein bar", calories: 200, time: "15:00" },
  ])

  const [newMeal, setNewMeal] = useState<Omit<Meal, "id">>({
    name: "",
    calories: 0,
    time: "",
  })

  const [calorieGoal, setCalorieGoal] = useState(2000)

  const handleAddMeal = () => {
    if (newMeal.name && newMeal.calories > 0) {
      setMeals([
        ...meals,
        {
          id: Date.now().toString(),
          ...newMeal,
        },
      ])
      setNewMeal({
        name: "",
        calories: 0,
        time: "",
      })
    }
  }

  const handleDeleteMeal = (id: string) => {
    setMeals(meals.filter((meal) => meal.id !== id))
  }

  const totalCalories = meals.reduce((sum, meal) => sum + meal.calories, 0)
  const caloriesRemaining = calorieGoal - totalCalories
  const progressPercentage = Math.min(100, (totalCalories / calorieGoal) * 100)

  return (
    <div className="grid gap-6 md:grid-cols-2">
      <Card className="overflow-hidden border-none bg-background/60 backdrop-blur-lg shadow-xl">
        <CardHeader className="bg-gradient-to-r from-orange-500/10 to-amber-500/10 dark:from-orange-500/20 dark:to-amber-500/20">
          <CardTitle>Meal Logger</CardTitle>
          <CardDescription>Track your daily food intake</CardDescription>
        </CardHeader>
        <CardContent className="p-6">
          <div className="space-y-4 mb-6">
            <div className="grid grid-cols-3 gap-4">
              <motion.div
                className="col-span-3 md:col-span-1"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.1 }}
              >
                <div className="text-center p-4 bg-gradient-to-br from-orange-100 to-amber-100 dark:from-orange-900/30 dark:to-amber-900/30 rounded-lg">
                  <div className="text-sm text-muted-foreground">Goal</div>
                  <div className="text-2xl font-bold">{calorieGoal}</div>
                  <div className="text-xs text-muted-foreground">calories</div>
                </div>
              </motion.div>
              <motion.div
                className="col-span-3 md:col-span-1"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.2 }}
              >
                <div className="text-center p-4 bg-gradient-to-br from-orange-100 to-amber-100 dark:from-orange-900/30 dark:to-amber-900/30 rounded-lg">
                  <div className="text-sm text-muted-foreground">Consumed</div>
                  <div className="text-2xl font-bold">{totalCalories}</div>
                  <div className="text-xs text-muted-foreground">calories</div>
                </div>
              </motion.div>
              <motion.div
                className="col-span-3 md:col-span-1"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.3 }}
              >
                <div className="text-center p-4 bg-gradient-to-br from-orange-100 to-amber-100 dark:from-orange-900/30 dark:to-amber-900/30 rounded-lg">
                  <div className="text-sm text-muted-foreground">Remaining</div>
                  <div className={`text-2xl font-bold ${caloriesRemaining < 0 ? "text-red-500" : ""}`}>
                    {caloriesRemaining}
                  </div>
                  <div className="text-xs text-muted-foreground">calories</div>
                </div>
              </motion.div>
            </div>

            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span>Daily Progress</span>
                <span>
                  {totalCalories} / {calorieGoal} calories
                </span>
              </div>
              <Progress
                value={progressPercentage}
                className="h-3 [&>div]:bg-gradient-to-r [&>div]:from-orange-500 [&>div]:to-amber-500"
              />
            </div>
          </div>

          <div className="space-y-4">
            <div className="grid gap-2">
              <Label htmlFor="meal-name">Meal Name</Label>
              <Input
                id="meal-name"
                placeholder="Enter meal name"
                value={newMeal.name}
                onChange={(e) => setNewMeal({ ...newMeal, name: e.target.value })}
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="grid gap-2">
                <Label htmlFor="calories">Calories</Label>
                <Input
                  id="calories"
                  type="number"
                  placeholder="0"
                  value={newMeal.calories || ""}
                  onChange={(e) => setNewMeal({ ...newMeal, calories: Number.parseInt(e.target.value) || 0 })}
                />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="time">Time</Label>
                <Input
                  id="time"
                  type="time"
                  value={newMeal.time}
                  onChange={(e) => setNewMeal({ ...newMeal, time: e.target.value })}
                />
              </div>
            </div>

            <motion.div whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }}>
              <Button
                className="w-full bg-gradient-to-r from-orange-500 to-amber-500 hover:from-orange-600 hover:to-amber-600"
                onClick={handleAddMeal}
                disabled={!newMeal.name || newMeal.calories <= 0}
              >
                <Plus className="mr-2 h-4 w-4" /> Add Meal
              </Button>
            </motion.div>
          </div>
        </CardContent>
      </Card>

      <Card className="overflow-hidden border-none bg-background/60 backdrop-blur-lg shadow-xl">
        <CardHeader className="bg-gradient-to-r from-orange-500/10 to-amber-500/10 dark:from-orange-500/20 dark:to-amber-500/20">
          <CardTitle>Today's Meals</CardTitle>
          <CardDescription>Your food intake for the day</CardDescription>
        </CardHeader>
        <CardContent className="p-6">
          <div className="space-y-4">
            <AnimatePresence>
              {meals.length === 0 ? (
                <div className="text-center py-6 text-muted-foreground">No meals logged today</div>
              ) : (
                meals.map((meal, index) => (
                  <motion.div
                    key={meal.id}
                    className="flex items-center justify-between p-3 border rounded-lg bg-gradient-to-r from-orange-50 to-amber-50 dark:from-orange-900/10 dark:to-amber-900/10"
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -20 }}
                    transition={{ delay: index * 0.1 }}
                  >
                    <div>
                      <div className="font-medium">{meal.name}</div>
                      <div className="text-sm text-muted-foreground">{meal.time}</div>
                    </div>
                    <div className="flex items-center gap-4">
                      <div className="text-sm font-medium">{meal.calories} cal</div>
                      <Button variant="ghost" size="icon" onClick={() => handleDeleteMeal(meal.id)}>
                        <Trash2 className="h-4 w-4 text-muted-foreground" />
                      </Button>
                    </div>
                  </motion.div>
                ))
              )}
            </AnimatePresence>
          </div>
        </CardContent>
        <CardFooter className="flex justify-between border-t px-6 py-4">
          <div className="text-sm text-muted-foreground">Total Meals: {meals.length}</div>
          <div className="font-medium">Total: {totalCalories} calories</div>
        </CardFooter>
      </Card>
    </div>
  )
}
