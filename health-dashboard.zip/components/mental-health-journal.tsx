"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Badge } from "@/components/ui/badge"
import { Calendar } from "@/components/ui/calendar"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Bar, BarChart, XAxis, YAxis, CartesianGrid, ResponsiveContainer } from "recharts"
import { ChartContainer, ChartTooltip, ChartTooltipContent } from "@/components/ui/chart"
import { Plus, Trash2, CalendarIcon, Tag } from "lucide-react"
import { motion, AnimatePresence } from "framer-motion"

interface JournalEntry {
  id: string
  date: string
  mood: number
  content: string
  tags: string[]
}

export function MentalHealthJournal() {
  const [entries, setEntries] = useState<JournalEntry[]>([
    {
      id: "1",
      date: "2023-05-10",
      mood: 4,
      content: "Had a productive day at work. Completed all my tasks and had time for a walk in the evening.",
      tags: ["work", "exercise", "productive"],
    },
    {
      id: "2",
      date: "2023-05-11",
      mood: 3,
      content: "Feeling a bit stressed about the upcoming deadline, but managed to stay focused.",
      tags: ["work", "stress"],
    },
    {
      id: "3",
      date: "2023-05-12",
      mood: 5,
      content: "Great day! Spent time with friends and enjoyed a nice dinner.",
      tags: ["social", "relaxation"],
    },
    {
      id: "4",
      date: "2023-05-13",
      mood: 2,
      content: "Didn't sleep well last night. Feeling tired and irritable today.",
      tags: ["sleep", "tired"],
    },
    {
      id: "5",
      date: "2023-05-14",
      mood: 4,
      content: "Went for a long hike today. The fresh air really helped clear my mind.",
      tags: ["exercise", "nature", "relaxation"],
    },
    {
      id: "6",
      date: "2023-05-15",
      mood: 3,
      content: "Average day. Nothing special happened, but feeling okay overall.",
      tags: ["neutral"],
    },
    {
      id: "7",
      date: "2023-05-16",
      mood: 4,
      content: "Started reading a new book. Really enjoying it so far.",
      tags: ["reading", "relaxation"],
    },
  ])

  const [newEntry, setNewEntry] = useState<Omit<JournalEntry, "id">>({
    date: new Date().toISOString().split("T")[0],
    mood: 3,
    content: "",
    tags: [],
  })

  const [newTag, setNewTag] = useState("")
  const [selectedDate, setSelectedDate] = useState<Date | undefined>(new Date())

  const handleAddEntry = () => {
    if (newEntry.content) {
      setEntries([
        ...entries,
        {
          id: Date.now().toString(),
          ...newEntry,
        },
      ])
      setNewEntry({
        date: new Date().toISOString().split("T")[0],
        mood: 3,
        content: "",
        tags: [],
      })
    }
  }

  const handleDeleteEntry = (id: string) => {
    setEntries(entries.filter((entry) => entry.id !== id))
  }

  const handleAddTag = () => {
    if (newTag && !newEntry.tags.includes(newTag)) {
      setNewEntry({
        ...newEntry,
        tags: [...newEntry.tags, newTag],
      })
      setNewTag("")
    }
  }

  const handleRemoveTag = (tag: string) => {
    setNewEntry({
      ...newEntry,
      tags: newEntry.tags.filter((t) => t !== tag),
    })
  }

  const getMoodLabel = (mood: number) => {
    switch (mood) {
      case 1:
        return "Very Poor"
      case 2:
        return "Poor"
      case 3:
        return "Neutral"
      case 4:
        return "Good"
      case 5:
        return "Excellent"
      default:
        return "Unknown"
    }
  }

  const getMoodColor = (mood: number) => {
    switch (mood) {
      case 1:
        return "bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-300"
      case 2:
        return "bg-orange-100 text-orange-800 dark:bg-orange-900/30 dark:text-orange-300"
      case 3:
        return "bg-yellow-100 text-yellow-800 dark:bg-yellow-900/30 dark:text-yellow-300"
      case 4:
        return "bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-300"
      case 5:
        return "bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-300"
      default:
        return "bg-gray-100 text-gray-800 dark:bg-gray-900/30 dark:text-gray-300"
    }
  }

  const getDayMood = (day: Date) => {
    const dateString = day.toISOString().split("T")[0]
    const entry = entries.find((e) => e.date === dateString)

    if (!entry) return ""

    const moodColorMap = {
      1: "bg-red-200 dark:bg-red-900/50",
      2: "bg-orange-200 dark:bg-orange-900/50",
      3: "bg-yellow-200 dark:bg-yellow-900/50",
      4: "bg-green-200 dark:bg-green-900/50",
      5: "bg-blue-200 dark:bg-blue-900/50",
    }

    return moodColorMap[entry.mood as keyof typeof moodColorMap] || ""
  }

  const getSelectedDateEntry = () => {
    if (!selectedDate) return null

    const dateString = selectedDate.toISOString().split("T")[0]
    return entries.find((entry) => entry.date === dateString)
  }

  const selectedEntry = getSelectedDateEntry()

  // Prepare chart data
  const chartData = [
    { name: "Very Poor", value: entries.filter((e) => e.mood === 1).length },
    { name: "Poor", value: entries.filter((e) => e.mood === 2).length },
    { name: "Neutral", value: entries.filter((e) => e.mood === 3).length },
    { name: "Good", value: entries.filter((e) => e.mood === 4).length },
    { name: "Excellent", value: entries.filter((e) => e.mood === 5).length },
  ]

  // Get all unique tags
  const allTags = Array.from(new Set(entries.flatMap((entry) => entry.tags)))

  // Prepare tag chart data
  const tagChartData = allTags
    .map((tag) => ({
      name: tag,
      value: entries.filter((entry) => entry.tags.includes(tag)).length,
    }))
    .sort((a, b) => b.value - a.value)
    .slice(0, 10)

  return (
    <div className="grid gap-6 md:grid-cols-2">
      <Card className="overflow-hidden border-none bg-background/60 backdrop-blur-lg shadow-xl">
        <CardHeader className="bg-gradient-to-r from-purple-500/10 to-fuchsia-500/10 dark:from-purple-500/20 dark:to-fuchsia-500/20">
          <CardTitle>Mental Health Journal</CardTitle>
          <CardDescription>Track your thoughts and feelings</CardDescription>
        </CardHeader>
        <CardContent className="p-6">
          <Tabs defaultValue="new">
            <TabsList className="grid w-full grid-cols-2 mb-4">
              <TabsTrigger value="new">New Entry</TabsTrigger>
              <TabsTrigger value="calendar">Calendar</TabsTrigger>
            </TabsList>

            <TabsContent value="new" className="space-y-4">
              <div className="grid gap-2">
                <Label htmlFor="entry-date">Date</Label>
                <Input
                  id="entry-date"
                  type="date"
                  value={newEntry.date}
                  onChange={(e) => setNewEntry({ ...newEntry, date: e.target.value })}
                />
              </div>

              <div className="grid gap-2">
                <Label htmlFor="entry-mood">Mood (1-5)</Label>
                <div className="grid grid-cols-5 gap-2">
                  {[1, 2, 3, 4, 5].map((mood) => (
                    <motion.div key={mood} whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                      <Button
                        type="button"
                        variant="outline"
                        className={`${newEntry.mood === mood ? "ring-2 ring-primary" : ""} ${getMoodColor(mood)}`}
                        onClick={() => setNewEntry({ ...newEntry, mood })}
                      >
                        {getMoodLabel(mood)}
                      </Button>
                    </motion.div>
                  ))}
                </div>
              </div>

              <div className="grid gap-2">
                <Label htmlFor="entry-content">Journal Entry</Label>
                <Textarea
                  id="entry-content"
                  placeholder="Write your thoughts and feelings here..."
                  rows={5}
                  value={newEntry.content}
                  onChange={(e) => setNewEntry({ ...newEntry, content: e.target.value })}
                  className="resize-none"
                />
              </div>

              <div className="grid gap-2">
                <Label htmlFor="entry-tags">Tags</Label>
                <div className="flex gap-2 mb-2">
                  <Input
                    id="entry-tags"
                    placeholder="Add a tag"
                    value={newTag}
                    onChange={(e) => setNewTag(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === "Enter") {
                        e.preventDefault()
                        handleAddTag()
                      }
                    }}
                  />
                  <Button type="button" variant="outline" onClick={handleAddTag} disabled={!newTag}>
                    <Plus className="h-4 w-4" />
                  </Button>
                </div>

                <div className="flex flex-wrap gap-2">
                  <AnimatePresence>
                    {newEntry.tags.map((tag) => (
                      <motion.div
                        key={tag}
                        initial={{ opacity: 0, scale: 0.8 }}
                        animate={{ opacity: 1, scale: 1 }}
                        exit={{ opacity: 0, scale: 0.8 }}
                      >
                        <Badge variant="secondary" className="flex items-center gap-1">
                          {tag}
                          <Button
                            type="button"
                            variant="ghost"
                            size="icon"
                            className="h-4 w-4 p-0 ml-1"
                            onClick={() => handleRemoveTag(tag)}
                          >
                            <Trash2 className="h-3 w-3" />
                          </Button>
                        </Badge>
                      </motion.div>
                    ))}
                  </AnimatePresence>
                </div>
              </div>

              <motion.div whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }}>
                <Button
                  className="w-full bg-gradient-to-r from-purple-500 to-fuchsia-500 hover:from-purple-600 hover:to-fuchsia-600"
                  onClick={handleAddEntry}
                  disabled={!newEntry.content}
                >
                  <Plus className="mr-2 h-4 w-4" /> Add Journal Entry
                </Button>
              </motion.div>
            </TabsContent>

            <TabsContent value="calendar">
              <Calendar
                mode="single"
                selected={selectedDate}
                onSelect={setSelectedDate}
                modifiers={{
                  booked: entries.map((entry) => new Date(entry.date)),
                }}
                modifiersClassNames={{
                  booked: "mood-day",
                }}
                components={{
                  DayContent: ({ date }) => (
                    <div className={`h-9 w-9 rounded-md flex items-center justify-center ${getDayMood(date)}`}>
                      {date.getDate()}
                    </div>
                  ),
                }}
                className="rounded-md border"
              />

              {selectedEntry && (
                <motion.div
                  className="mt-4 p-4 border rounded-lg bg-gradient-to-r from-purple-50 to-fuchsia-50 dark:from-purple-900/10 dark:to-fuchsia-900/10"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                >
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-2">
                      <CalendarIcon className="h-4 w-4 text-muted-foreground" />
                      <span className="text-sm text-muted-foreground">
                        {new Date(selectedEntry.date).toLocaleDateString("en-US", {
                          weekday: "long",
                          year: "numeric",
                          month: "long",
                          day: "numeric",
                        })}
                      </span>
                    </div>
                    <Badge className={getMoodColor(selectedEntry.mood)}>{getMoodLabel(selectedEntry.mood)}</Badge>
                  </div>

                  <p className="mb-3">{selectedEntry.content}</p>

                  {selectedEntry.tags.length > 0 && (
                    <div className="flex items-center gap-2">
                      <Tag className="h-4 w-4 text-muted-foreground" />
                      <div className="flex flex-wrap gap-1">
                        {selectedEntry.tags.map((tag) => (
                          <Badge key={tag} variant="outline" className="text-xs">
                            {tag}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  )}
                </motion.div>
              )}
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>

      <Card className="overflow-hidden border-none bg-background/60 backdrop-blur-lg shadow-xl">
        <CardHeader className="bg-gradient-to-r from-purple-500/10 to-fuchsia-500/10 dark:from-purple-500/20 dark:to-fuchsia-500/20">
          <CardTitle>Mood Analysis</CardTitle>
          <CardDescription>Visualize your mood patterns</CardDescription>
        </CardHeader>
        <CardContent className="p-6">
          <Tabs defaultValue="mood">
            <TabsList className="grid w-full grid-cols-2 mb-4">
              <TabsTrigger value="mood">Mood Distribution</TabsTrigger>
              <TabsTrigger value="tags">Common Tags</TabsTrigger>
            </TabsList>

            <TabsContent value="mood">
              <div className="h-[300px] mb-6">
                <ChartContainer
                  config={{
                    value: {
                      label: "Count",
                      color: "hsl(var(--chart-1))",
                    },
                  }}
                >
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={chartData}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="name" />
                      <YAxis />
                      <ChartTooltip content={<ChartTooltipContent />} />
                      <Bar dataKey="value" fill="var(--color-value)" />
                    </BarChart>
                  </ResponsiveContainer>
                </ChartContainer>
              </div>

              <div className="grid grid-cols-5 gap-2 mb-4">
                {[1, 2, 3, 4, 5].map((mood) => (
                  <div key={mood} className="text-center">
                    <div className={`p-2 rounded-md ${getMoodColor(mood)}`}>{getMoodLabel(mood)}</div>
                    <div className="text-lg font-bold mt-1">{entries.filter((e) => e.mood === mood).length}</div>
                    <div className="text-xs text-muted-foreground">entries</div>
                  </div>
                ))}
              </div>
            </TabsContent>

            <TabsContent value="tags">
              <div className="h-[300px] mb-6">
                <ChartContainer
                  config={{
                    value: {
                      label: "Count",
                      color: "hsl(var(--chart-2))",
                    },
                  }}
                >
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={tagChartData} layout="vertical">
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis type="number" />
                      <YAxis dataKey="name" type="category" width={100} />
                      <ChartTooltip content={<ChartTooltipContent />} />
                      <Bar dataKey="value" fill="var(--color-value)" />
                    </BarChart>
                  </ResponsiveContainer>
                </ChartContainer>
              </div>

              <div className="flex flex-wrap gap-2">
                <AnimatePresence>
                  {allTags.map((tag) => {
                    const count = entries.filter((entry) => entry.tags.includes(tag)).length
                    return (
                      <motion.div key={tag} initial={{ opacity: 0, scale: 0.8 }} animate={{ opacity: 1, scale: 1 }}>
                        <Badge variant="outline" className="flex items-center gap-1">
                          {tag}
                          <span className="ml-1 bg-muted text-muted-foreground rounded-full px-1.5 py-0.5 text-xs">
                            {count}
                          </span>
                        </Badge>
                      </motion.div>
                    )
                  })}
                </AnimatePresence>
              </div>
            </TabsContent>
          </Tabs>
        </CardContent>
        <CardFooter className="flex justify-between border-t px-6 py-4">
          <div className="text-sm text-muted-foreground">Total Entries: {entries.length}</div>
          <div className="font-medium">
            Average Mood: {(entries.reduce((sum, entry) => sum + entry.mood, 0) / entries.length).toFixed(1)}
          </div>
        </CardFooter>
      </Card>
    </div>
  )
}
