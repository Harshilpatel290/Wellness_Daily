"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Calendar } from "@/components/ui/calendar"
import { Badge } from "@/components/ui/badge"
import { motion } from "framer-motion"

type Mood = "happy" | "good" | "neutral" | "sad" | "angry" | null

interface MoodData {
  [date: string]: Mood
}

export function MoodTracker() {
  const [selectedMood, setSelectedMood] = useState<Mood>(null)
  const [moodData, setMoodData] = useState<MoodData>({
    "2023-05-10": "happy",
    "2023-05-11": "good",
    "2023-05-12": "neutral",
    "2023-05-13": "sad",
    "2023-05-14": "angry",
    "2023-05-15": "good",
    "2023-05-16": "happy",
  })
  const [date, setDate] = useState<Date>(new Date())

  const moodEmojis = {
    happy: "😄",
    good: "🙂",
    neutral: "😐",
    sad: "😔",
    angry: "😠",
  }

  const moodColors = {
    happy: "bg-green-100 hover:bg-green-200 dark:bg-green-900/30 dark:hover:bg-green-900/50",
    good: "bg-blue-100 hover:bg-blue-200 dark:bg-blue-900/30 dark:hover:bg-blue-900/50",
    neutral: "bg-yellow-100 hover:bg-yellow-200 dark:bg-yellow-900/30 dark:hover:bg-yellow-900/50",
    sad: "bg-orange-100 hover:bg-orange-200 dark:bg-orange-900/30 dark:hover:bg-orange-900/50",
    angry: "bg-red-100 hover:bg-red-200 dark:bg-red-900/30 dark:hover:bg-red-900/50",
  }

  const moodLabels = {
    happy: "Happy",
    good: "Good",
    neutral: "Neutral",
    sad: "Sad",
    angry: "Angry",
  }

  const handleMoodSelect = (mood: Mood) => {
    setSelectedMood(mood)
    const dateString = date.toISOString().split("T")[0]
    setMoodData({
      ...moodData,
      [dateString]: mood,
    })
  }

  const getDayColor = (day: Date) => {
    const dateString = day.toISOString().split("T")[0]
    const mood = moodData[dateString]

    if (!mood) return ""

    const colorMap = {
      happy: "bg-green-200 dark:bg-green-900/50",
      good: "bg-blue-200 dark:bg-blue-900/50",
      neutral: "bg-yellow-200 dark:bg-yellow-900/50",
      sad: "bg-orange-200 dark:bg-orange-900/50",
      angry: "bg-red-200 dark:bg-red-900/50",
    }

    return colorMap[mood]
  }

  const getMoodStats = () => {
    const stats = {
      happy: 0,
      good: 0,
      neutral: 0,
      sad: 0,
      angry: 0,
    }

    Object.values(moodData).forEach((mood) => {
      if (mood) stats[mood]++
    })

    return stats
  }

  const moodStats = getMoodStats()

  return (
    <div className="grid gap-6 md:grid-cols-2">
      <Card className="overflow-hidden border-none bg-background/60 backdrop-blur-lg shadow-xl">
        <CardHeader className="bg-gradient-to-r from-green-500/10 to-emerald-500/10 dark:from-green-500/20 dark:to-emerald-500/20">
          <CardTitle>Mood Tracker</CardTitle>
          <CardDescription>Track how you feel each day</CardDescription>
        </CardHeader>
        <CardContent className="p-6">
          <div className="mb-6">
            <p className="text-sm text-muted-foreground mb-3">How are you feeling today?</p>
            <div className="grid grid-cols-5 gap-2">
              {(Object.keys(moodEmojis) as Mood[]).map((mood) => (
                <motion.div key={mood} whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                  <Button
                    variant="outline"
                    className={`text-2xl h-14 w-full ${selectedMood === mood ? "ring-2 ring-primary" : ""} ${moodColors[mood]}`}
                    onClick={() => handleMoodSelect(mood)}
                  >
                    {moodEmojis[mood]}
                  </Button>
                </motion.div>
              ))}
            </div>
          </div>

          <div className="mt-6">
            <p className="text-sm text-muted-foreground mb-2">
              Selected mood:{" "}
              {selectedMood ? (
                <Badge variant="outline" className="ml-2">
                  {moodEmojis[selectedMood]} {moodLabels[selectedMood]}
                </Badge>
              ) : (
                "None selected"
              )}
            </p>
          </div>

          <div className="mt-6 grid grid-cols-5 gap-2">
            {(Object.keys(moodEmojis) as Mood[]).map((mood) => (
              <div key={mood} className="text-center">
                <div className={`rounded-full w-10 h-10 mx-auto flex items-center justify-center ${moodColors[mood]}`}>
                  {moodStats[mood]}
                </div>
                <p className="text-xs mt-1">{moodEmojis[mood]}</p>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      <Card className="overflow-hidden border-none bg-background/60 backdrop-blur-lg shadow-xl">
        <CardHeader className="bg-gradient-to-r from-green-500/10 to-emerald-500/10 dark:from-green-500/20 dark:to-emerald-500/20">
          <CardTitle>Mood Calendar</CardTitle>
          <CardDescription>View your mood history</CardDescription>
        </CardHeader>
        <CardContent className="p-6">
          <Calendar
            mode="single"
            selected={date}
            onSelect={(newDate) => newDate && setDate(newDate)}
            modifiers={{
              booked: Object.keys(moodData).map((dateStr) => new Date(dateStr)),
            }}
            modifiersClassNames={{
              booked: "mood-day",
            }}
            components={{
              DayContent: ({ date }) => (
                <div className={`h-9 w-9 rounded-md flex items-center justify-center ${getDayColor(date)}`}>
                  {date.getDate()}
                  {moodData[date.toISOString().split("T")[0]] && (
                    <span className="absolute bottom-1 text-xs">
                      {moodEmojis[moodData[date.toISOString().split("T")[0]]]}
                    </span>
                  )}
                </div>
              ),
            }}
            className="rounded-md border"
          />
        </CardContent>
      </Card>
    </div>
  )
}
