"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Moon, Plus, Trash2 } from "lucide-react"
import { Line, LineChart, XAxis, YAxis, CartesianGrid, ResponsiveContainer } from "recharts"
import { ChartContainer, ChartTooltip, ChartTooltipContent } from "@/components/ui/chart"
import { motion, AnimatePresence } from "framer-motion"

interface SleepEntry {
  id: string
  date: string
  hoursSlept: number
  quality: number
  notes: string
}

export function SleepTracker() {
  const [sleepEntries, setSleepEntries] = useState<SleepEntry[]>([
    { id: "1", date: "2023-05-10", hoursSlept: 7.5, quality: 4, notes: "Woke up once" },
    { id: "2", date: "2023-05-11", hoursSlept: 6.2, quality: 3, notes: "Restless night" },
    { id: "3", date: "2023-05-12", hoursSlept: 8.0, quality: 5, notes: "Slept well" },
    { id: "4", date: "2023-05-13", hoursSlept: 7.0, quality: 4, notes: "Normal sleep" },
    { id: "5", date: "2023-05-14", hoursSlept: 8.5, quality: 5, notes: "Great sleep" },
    { id: "6", date: "2023-05-15", hoursSlept: 6.8, quality: 3, notes: "Woke up early" },
    { id: "7", date: "2023-05-16", hoursSlept: 7.2, quality: 4, notes: "Decent sleep" },
  ])

  const [newEntry, setNewEntry] = useState<Omit<SleepEntry, "id">>({
    date: new Date().toISOString().split("T")[0],
    hoursSlept: 7,
    quality: 3,
    notes: "",
  })

  const handleAddEntry = () => {
    setSleepEntries([
      ...sleepEntries,
      {
        id: Date.now().toString(),
        ...newEntry,
      },
    ])
    setNewEntry({
      date: new Date().toISOString().split("T")[0],
      hoursSlept: 7,
      quality: 3,
      notes: "",
    })
  }

  const handleDeleteEntry = (id: string) => {
    setSleepEntries(sleepEntries.filter((entry) => entry.id !== id))
  }

  const averageSleep =
    sleepEntries.length > 0 ? sleepEntries.reduce((sum, entry) => sum + entry.hoursSlept, 0) / sleepEntries.length : 0

  const chartData = [...sleepEntries]
    .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime())
    .map((entry) => ({
      date: new Date(entry.date).toLocaleDateString("en-US", { month: "short", day: "numeric" }),
      hours: entry.hoursSlept,
      quality: entry.quality,
    }))

  return (
    <div className="grid gap-6 md:grid-cols-2">
      <Card className="overflow-hidden border-none bg-background/60 backdrop-blur-lg shadow-xl">
        <CardHeader className="bg-gradient-to-r from-indigo-500/10 to-violet-500/10 dark:from-indigo-500/20 dark:to-violet-500/20">
          <CardTitle>Sleep Tracker</CardTitle>
          <CardDescription>Track your sleep duration and quality</CardDescription>
        </CardHeader>
        <CardContent className="p-6">
          <div className="space-y-4 mb-6">
            <div className="grid grid-cols-2 gap-4">
              <motion.div
                className="col-span-2 md:col-span-1"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.1 }}
              >
                <div className="text-center p-4 bg-gradient-to-br from-indigo-100 to-violet-100 dark:from-indigo-900/30 dark:to-violet-900/30 rounded-lg">
                  <div className="text-sm text-muted-foreground">Average Sleep</div>
                  <div className="text-2xl font-bold">{averageSleep.toFixed(1)}</div>
                  <div className="text-xs text-muted-foreground">hours per night</div>
                </div>
              </motion.div>
              <motion.div
                className="col-span-2 md:col-span-1"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.2 }}
              >
                <div className="text-center p-4 bg-gradient-to-br from-indigo-100 to-violet-100 dark:from-indigo-900/30 dark:to-violet-900/30 rounded-lg">
                  <div className="text-sm text-muted-foreground">Entries</div>
                  <div className="text-2xl font-bold">{sleepEntries.length}</div>
                  <div className="text-xs text-muted-foreground">days tracked</div>
                </div>
              </motion.div>
            </div>
          </div>

          <div className="space-y-4">
            <div className="grid gap-2">
              <Label htmlFor="sleep-date">Date</Label>
              <Input
                id="sleep-date"
                type="date"
                value={newEntry.date}
                onChange={(e) => setNewEntry({ ...newEntry, date: e.target.value })}
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="grid gap-2">
                <Label htmlFor="hours-slept">Hours Slept</Label>
                <Input
                  id="hours-slept"
                  type="number"
                  step="0.1"
                  min="0"
                  max="24"
                  value={newEntry.hoursSlept}
                  onChange={(e) => setNewEntry({ ...newEntry, hoursSlept: Number.parseFloat(e.target.value) || 0 })}
                />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="sleep-quality">Sleep Quality (1-5)</Label>
                <Input
                  id="sleep-quality"
                  type="number"
                  min="1"
                  max="5"
                  value={newEntry.quality}
                  onChange={(e) => setNewEntry({ ...newEntry, quality: Number.parseInt(e.target.value) || 1 })}
                />
              </div>
            </div>

            <div className="grid gap-2">
              <Label htmlFor="sleep-notes">Notes</Label>
              <Input
                id="sleep-notes"
                placeholder="Any notes about your sleep"
                value={newEntry.notes}
                onChange={(e) => setNewEntry({ ...newEntry, notes: e.target.value })}
              />
            </div>

            <motion.div whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }}>
              <Button
                className="w-full bg-gradient-to-r from-indigo-500 to-violet-500 hover:from-indigo-600 hover:to-violet-600"
                onClick={handleAddEntry}
              >
                <Plus className="mr-2 h-4 w-4" /> Add Sleep Entry
              </Button>
            </motion.div>
          </div>
        </CardContent>
      </Card>

      <Card className="overflow-hidden border-none bg-background/60 backdrop-blur-lg shadow-xl">
        <CardHeader className="bg-gradient-to-r from-indigo-500/10 to-violet-500/10 dark:from-indigo-500/20 dark:to-violet-500/20">
          <CardTitle>Sleep History</CardTitle>
          <CardDescription>Your recent sleep patterns</CardDescription>
        </CardHeader>
        <CardContent className="p-6">
          <div className="h-[300px] mb-6">
            <ChartContainer
              config={{
                hours: {
                  label: "Hours Slept",
                  color: "hsl(var(--chart-1))",
                },
                quality: {
                  label: "Sleep Quality",
                  color: "hsl(var(--chart-2))",
                },
              }}
            >
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={chartData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="date" />
                  <YAxis yAxisId="left" domain={[0, 10]} />
                  <YAxis yAxisId="right" orientation="right" domain={[0, 5]} />
                  <ChartTooltip content={<ChartTooltipContent />} />
                  <Line
                    yAxisId="left"
                    type="monotone"
                    dataKey="hours"
                    stroke="var(--color-hours)"
                    strokeWidth={2}
                    dot={{ r: 4 }}
                    activeDot={{ r: 6 }}
                  />
                  <Line
                    yAxisId="right"
                    type="monotone"
                    dataKey="quality"
                    stroke="var(--color-quality)"
                    strokeWidth={2}
                    dot={{ r: 4 }}
                    activeDot={{ r: 6 }}
                  />
                </LineChart>
              </ResponsiveContainer>
            </ChartContainer>
          </div>

          <div className="space-y-4">
            <h3 className="text-sm font-medium">Recent Entries</h3>
            <AnimatePresence>
              <div className="space-y-2">
                {sleepEntries
                  .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
                  .slice(0, 3)
                  .map((entry, index) => (
                    <motion.div
                      key={entry.id}
                      className="flex items-center justify-between p-3 border rounded-lg bg-gradient-to-r from-indigo-50 to-violet-50 dark:from-indigo-900/10 dark:to-violet-900/10"
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: -20 }}
                      transition={{ delay: index * 0.1 }}
                    >
                      <div className="flex items-center gap-3">
                        <Moon className="h-5 w-5 text-indigo-500 dark:text-indigo-400" />
                        <div>
                          <div className="font-medium">
                            {new Date(entry.date).toLocaleDateString("en-US", {
                              weekday: "short",
                              month: "short",
                              day: "numeric",
                            })}
                          </div>
                          <div className="text-sm text-muted-foreground">{entry.notes || "No notes"}</div>
                        </div>
                      </div>
                      <div className="flex items-center gap-4">
                        <div className="text-right">
                          <div className="font-medium">{entry.hoursSlept} hrs</div>
                          <div className="text-sm text-muted-foreground">Quality: {entry.quality}/5</div>
                        </div>
                        <Button variant="ghost" size="icon" onClick={() => handleDeleteEntry(entry.id)}>
                          <Trash2 className="h-4 w-4 text-muted-foreground" />
                        </Button>
                      </div>
                    </motion.div>
                  ))}
              </div>
            </AnimatePresence>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
