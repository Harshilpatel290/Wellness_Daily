"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Progress } from "@/components/ui/progress"
import { Play, Pause, RotateCcw, Plus, Trash2, GripVertical, ArrowRight } from "lucide-react"
import { motion, AnimatePresence } from "framer-motion"

interface StretchExercise {
  id: string
  name: string
  duration: number
  description: string
}

export function StretchSequence() {
  const [exercises, setExercises] = useState<StretchExercise[]>([
    {
      id: "1",
      name: "Neck Stretch",
      duration: 30,
      description: "Gently tilt your head to each side, holding for a few seconds.",
    },
    {
      id: "2",
      name: "Shoulder Rolls",
      duration: 30,
      description: "Roll your shoulders forward and backward in a circular motion.",
    },
    {
      id: "3",
      name: "Quad Stretch",
      duration: 45,
      description: "Stand on one leg, grab your ankle, and pull your heel toward your buttocks.",
    },
    {
      id: "4",
      name: "Hamstring Stretch",
      duration: 45,
      description: "Sit with one leg extended, reach toward your toes.",
    },
    {
      id: "5",
      name: "Child's Pose",
      duration: 60,
      description: "Kneel and extend arms forward, lowering chest to ground.",
    },
  ])

  const [currentExerciseIndex, setCurrentExerciseIndex] = useState(-1)
  const [timer, setTimer] = useState(0)
  const [isRunning, setIsRunning] = useState(false)

  const [newExercise, setNewExercise] = useState({
    name: "",
    duration: 30,
    description: "",
  })

  const [draggedExercise, setDraggedExercise] = useState<string | null>(null)

  useEffect(() => {
    let interval: NodeJS.Timeout | null = null

    if (isRunning && currentExerciseIndex >= 0 && currentExerciseIndex < exercises.length) {
      interval = setInterval(() => {
        setTimer((prevTimer) => {
          const newTimer = prevTimer + 1
          const currentExercise = exercises[currentExerciseIndex]

          if (newTimer >= currentExercise.duration) {
            if (currentExerciseIndex < exercises.length - 1) {
              setCurrentExerciseIndex(currentExerciseIndex + 1)
              return 0
            } else {
              setIsRunning(false)
              setCurrentExerciseIndex(-1)
              return 0
            }
          }

          return newTimer
        })
      }, 1000)
    }

    return () => {
      if (interval) clearInterval(interval)
    }
  }, [isRunning, currentExerciseIndex, exercises])

  const startSequence = () => {
    if (exercises.length > 0) {
      setCurrentExerciseIndex(0)
      setTimer(0)
      setIsRunning(true)
    }
  }

  const toggleTimer = () => {
    setIsRunning(!isRunning)
  }

  const resetSequence = () => {
    setCurrentExerciseIndex(-1)
    setTimer(0)
    setIsRunning(false)
  }

  const nextExercise = () => {
    if (currentExerciseIndex < exercises.length - 1) {
      setCurrentExerciseIndex(currentExerciseIndex + 1)
      setTimer(0)
    } else {
      resetSequence()
    }
  }

  const handleAddExercise = () => {
    if (newExercise.name && newExercise.duration > 0) {
      setExercises([
        ...exercises,
        {
          id: Date.now().toString(),
          name: newExercise.name,
          duration: newExercise.duration,
          description: newExercise.description,
        },
      ])
      setNewExercise({
        name: "",
        duration: 30,
        description: "",
      })
    }
  }

  const handleDeleteExercise = (id: string) => {
    const index = exercises.findIndex((ex) => ex.id === id)

    setExercises(exercises.filter((exercise) => exercise.id !== id))

    if (currentExerciseIndex === index) {
      resetSequence()
    } else if (currentExerciseIndex > index) {
      setCurrentExerciseIndex(currentExerciseIndex - 1)
    }
  }

  const handleDragStart = (id: string) => {
    setDraggedExercise(id)
  }

  const handleDragOver = (e: React.DragEvent, id: string) => {
    e.preventDefault()

    if (draggedExercise && draggedExercise !== id) {
      const draggedIndex = exercises.findIndex((ex) => ex.id === draggedExercise)
      const targetIndex = exercises.findIndex((ex) => ex.id === id)

      if (draggedIndex !== -1 && targetIndex !== -1) {
        const newExercises = [...exercises]
        const [removed] = newExercises.splice(draggedIndex, 1)
        newExercises.splice(targetIndex, 0, removed)

        setExercises(newExercises)

        if (currentExerciseIndex === draggedIndex) {
          setCurrentExerciseIndex(targetIndex)
        } else if (currentExerciseIndex === targetIndex) {
          setCurrentExerciseIndex(draggedIndex)
        }
      }
    }
  }

  const handleDragEnd = () => {
    setDraggedExercise(null)
  }

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60)
    const secs = seconds % 60
    return `${mins.toString().padStart(2, "0")}:${secs.toString().padStart(2, "0")}`
  }

  const totalDuration = exercises.reduce((sum, ex) => sum + ex.duration, 0)
  const currentExercise = currentExerciseIndex >= 0 ? exercises[currentExerciseIndex] : null

  return (
    <div className="grid gap-6 md:grid-cols-2">
      <Card className="overflow-hidden border-none bg-background/60 backdrop-blur-lg shadow-xl">
        <CardHeader className="bg-gradient-to-r from-teal-500/10 to-emerald-500/10 dark:from-teal-500/20 dark:to-emerald-500/20">
          <CardTitle>Stretch Sequence</CardTitle>
          <CardDescription>Create and follow your stretching routine</CardDescription>
        </CardHeader>
        <CardContent className="p-6">
          {currentExercise ? (
            <motion.div
              className="mb-6 p-4 border rounded-lg bg-gradient-to-r from-teal-50 to-emerald-50 dark:from-teal-900/10 dark:to-emerald-900/10"
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.3 }}
            >
              <div className="text-center mb-4">
                <h3 className="text-xl font-bold">{currentExercise.name}</h3>
                <div className="text-sm text-muted-foreground mb-2">
                  {formatTime(timer)} / {formatTime(currentExercise.duration)}
                </div>
                <p className="text-sm">{currentExercise.description}</p>
              </div>

              <Progress
                value={(timer / currentExercise.duration) * 100}
                className="h-3 mb-4 [&>div]:bg-gradient-to-r [&>div]:from-teal-500 [&>div]:to-emerald-500"
              />

              <div className="flex justify-center gap-2">
                <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                  <Button
                    variant="outline"
                    size="icon"
                    onClick={toggleTimer}
                    className="bg-gradient-to-r from-teal-100 to-emerald-100 dark:from-teal-900/30 dark:to-emerald-900/30 hover:from-teal-200 hover:to-emerald-200 dark:hover:from-teal-900/50 dark:hover:to-emerald-900/50"
                  >
                    {isRunning ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4" />}
                  </Button>
                </motion.div>
                <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                  <Button
                    variant="outline"
                    onClick={nextExercise}
                    className="bg-gradient-to-r from-teal-100 to-emerald-100 dark:from-teal-900/30 dark:to-emerald-900/30 hover:from-teal-200 hover:to-emerald-200 dark:hover:from-teal-900/50 dark:hover:to-emerald-900/50"
                  >
                    <ArrowRight className="mr-2 h-4 w-4" /> Next
                  </Button>
                </motion.div>
                <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                  <Button
                    variant="outline"
                    size="icon"
                    onClick={resetSequence}
                    className="bg-gradient-to-r from-teal-100 to-emerald-100 dark:from-teal-900/30 dark:to-emerald-900/30 hover:from-teal-200 hover:to-emerald-200 dark:hover:from-teal-900/50 dark:hover:to-emerald-900/50"
                  >
                    <RotateCcw className="h-4 w-4" />
                  </Button>
                </motion.div>
              </div>
            </motion.div>
          ) : (
            <motion.div
              className="mb-6 p-4 border rounded-lg text-center bg-gradient-to-r from-teal-50 to-emerald-50 dark:from-teal-900/10 dark:to-emerald-900/10"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3 }}
            >
              <h3 className="text-lg font-medium mb-2">Start Your Stretch Sequence</h3>
              <p className="text-sm text-muted-foreground mb-4">
                Click the button below to begin your stretching routine
              </p>
              <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                <Button
                  onClick={startSequence}
                  disabled={exercises.length === 0}
                  className="bg-gradient-to-r from-teal-500 to-emerald-500 hover:from-teal-600 hover:to-emerald-600"
                >
                  <Play className="mr-2 h-4 w-4" /> Start Sequence
                </Button>
              </motion.div>
            </motion.div>
          )}

          <div className="space-y-4">
            <div className="grid gap-2">
              <Label htmlFor="stretch-name">Stretch Name</Label>
              <Input
                id="stretch-name"
                placeholder="Enter stretch name"
                value={newExercise.name}
                onChange={(e) => setNewExercise({ ...newExercise, name: e.target.value })}
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="grid gap-2">
                <Label htmlFor="stretch-duration">Duration (seconds)</Label>
                <Input
                  id="stretch-duration"
                  type="number"
                  min="5"
                  step="5"
                  value={newExercise.duration}
                  onChange={(e) => setNewExercise({ ...newExercise, duration: Number.parseInt(e.target.value) || 30 })}
                />
              </div>
            </div>

            <div className="grid gap-2">
              <Label htmlFor="stretch-description">Description</Label>
              <Input
                id="stretch-description"
                placeholder="How to perform this stretch"
                value={newExercise.description}
                onChange={(e) => setNewExercise({ ...newExercise, description: e.target.value })}
              />
            </div>

            <motion.div whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }}>
              <Button
                className="w-full bg-gradient-to-r from-teal-500 to-emerald-500 hover:from-teal-600 hover:to-emerald-600"
                onClick={handleAddExercise}
                disabled={!newExercise.name || newExercise.duration <= 0}
              >
                <Plus className="mr-2 h-4 w-4" /> Add Stretch
              </Button>
            </motion.div>
          </div>
        </CardContent>
      </Card>

      <Card className="overflow-hidden border-none bg-background/60 backdrop-blur-lg shadow-xl">
        <CardHeader className="bg-gradient-to-r from-teal-500/10 to-emerald-500/10 dark:from-teal-500/20 dark:to-emerald-500/20">
          <CardTitle>Stretch Sequence</CardTitle>
          <CardDescription>Drag to reorder your stretches</CardDescription>
        </CardHeader>
        <CardContent className="p-6">
          <AnimatePresence>
            <div className="space-y-4">
              {exercises.length === 0 ? (
                <div className="text-center py-6 text-muted-foreground">No stretches added yet</div>
              ) : (
                exercises.map((exercise, index) => (
                  <motion.div
                    key={exercise.id}
                    className={`flex items-start p-3 border rounded-lg ${
                      currentExerciseIndex === index ? "ring-2 ring-primary" : ""
                    } bg-gradient-to-r from-teal-50 to-emerald-50 dark:from-teal-900/10 dark:to-emerald-900/10`}
                    draggable
                    onDragStart={() => handleDragStart(exercise.id)}
                    onDragOver={(e) => handleDragOver(e, exercise.id)}
                    onDragEnd={handleDragEnd}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -20 }}
                    transition={{ delay: index * 0.05 }}
                  >
                    <div className="flex items-center self-center mr-2 cursor-move">
                      <GripVertical className="h-5 w-5 text-muted-foreground" />
                    </div>
                    <div className="flex-1">
                      <div className="font-medium">{exercise.name}</div>
                      <div className="text-sm text-muted-foreground mb-1">
                        Duration: {formatTime(exercise.duration)}
                      </div>
                      <div className="text-sm">{exercise.description}</div>
                    </div>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="ml-2"
                      onClick={() => handleDeleteExercise(exercise.id)}
                    >
                      <Trash2 className="h-4 w-4 text-muted-foreground" />
                    </Button>
                  </motion.div>
                ))
              )}
            </div>
          </AnimatePresence>
        </CardContent>
        <CardFooter className="flex justify-between border-t px-6 py-4">
          <div className="text-sm text-muted-foreground">Total Stretches: {exercises.length}</div>
          <div className="font-medium">Total Time: {formatTime(totalDuration)}</div>
        </CardFooter>
      </Card>
    </div>
  )
}
