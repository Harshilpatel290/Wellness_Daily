"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Slider } from "@/components/ui/slider"
import { Progress } from "@/components/ui/progress"
import { Droplet, Plus, Minus } from "lucide-react"
import { motion, AnimatePresence } from "framer-motion"

export function WaterIntakeTracker() {
  const [waterGoal, setWaterGoal] = useState(8)
  const [waterIntake, setWaterIntake] = useState(0)
  const [showAnimation, setShowAnimation] = useState(false)
  const [message, setMessage] = useState("")

  const handleAddWater = (amount: number) => {
    const newIntake = Math.max(0, Math.min(waterIntake + amount, 20))

    if (newIntake > waterIntake) {
      setShowAnimation(true)
      setTimeout(() => setShowAnimation(false), 1000)
    }

    setWaterIntake(newIntake)
  }

  useEffect(() => {
    const progressPercentage = (waterIntake / waterGoal) * 100

    if (progressPercentage === 0) {
      setMessage("Start hydrating!")
    } else if (progressPercentage < 25) {
      setMessage("Keep drinking!")
    } else if (progressPercentage < 50) {
      setMessage("You're doing great!")
    } else if (progressPercentage < 75) {
      setMessage("More than halfway there!")
    } else if (progressPercentage < 100) {
      setMessage("Almost there!")
    } else {
      setMessage("Goal achieved! 🎉")
    }
  }, [waterIntake, waterGoal])

  const progressPercentage = Math.min(100, (waterIntake / waterGoal) * 100)

  return (
    <div className="grid gap-6 md:grid-cols-2">
      <Card className="overflow-hidden border-none bg-background/60 backdrop-blur-lg shadow-xl">
        <CardHeader className="bg-gradient-to-r from-blue-500/10 to-cyan-500/10 dark:from-blue-500/20 dark:to-cyan-500/20">
          <CardTitle>Water Intake Tracker</CardTitle>
          <CardDescription>Track your daily water consumption</CardDescription>
        </CardHeader>
        <CardContent className="p-6 relative">
          <AnimatePresence>
            {showAnimation && (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                className="absolute top-0 left-0 w-full h-full flex items-center justify-center pointer-events-none"
              >
                <motion.div
                  animate={{
                    scale: [1, 1.2, 1],
                    opacity: [0.8, 1, 0],
                  }}
                  transition={{ duration: 1 }}
                  className="text-blue-500 dark:text-blue-400"
                >
                  <Droplet className="h-20 w-20" />
                </motion.div>
              </motion.div>
            )}
          </AnimatePresence>

          <div className="flex flex-col items-center mb-6">
            <div className="text-6xl font-bold text-blue-500 dark:text-blue-400 mb-2">{waterIntake}</div>
            <div className="text-sm text-muted-foreground">cups of water</div>
          </div>

          <Progress value={progressPercentage} className="h-3 mb-2" />

          <div className="text-center text-sm font-medium text-blue-500 dark:text-blue-400 mb-4">{message}</div>

          <div className="flex justify-between text-sm mb-6">
            <span>0 cups</span>
            <span>Goal: {waterGoal} cups</span>
            <span>20 cups</span>
          </div>

          <div className="flex justify-center gap-4 mb-6">
            <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
              <Button
                variant="outline"
                size="icon"
                onClick={() => handleAddWater(-1)}
                disabled={waterIntake <= 0}
                className="bg-red-100 dark:bg-red-900/30 hover:bg-red-200 dark:hover:bg-red-900/50"
              >
                <Minus className="h-4 w-4" />
              </Button>
            </motion.div>

            <div className="flex gap-2">
              {[1, 2, 3].map((amount) => (
                <motion.div key={amount} whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                  <Button
                    variant="outline"
                    className="relative h-16 w-12 bg-blue-100 dark:bg-blue-900/30 hover:bg-blue-200 dark:hover:bg-blue-900/50"
                    onClick={() => handleAddWater(amount)}
                  >
                    <Droplet className="h-6 w-6 text-blue-500 dark:text-blue-400" />
                    <span className="absolute -bottom-1 text-xs">+{amount}</span>
                  </Button>
                </motion.div>
              ))}
            </div>

            <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
              <Button
                variant="outline"
                size="icon"
                onClick={() => handleAddWater(1)}
                disabled={waterIntake >= 20}
                className="bg-green-100 dark:bg-green-900/30 hover:bg-green-200 dark:hover:bg-green-900/50"
              >
                <Plus className="h-4 w-4" />
              </Button>
            </motion.div>
          </div>

          <div className="space-y-4">
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span>Daily Goal</span>
                <span>{waterGoal} cups</span>
              </div>
              <Slider
                value={[waterGoal]}
                min={1}
                max={15}
                step={1}
                onValueChange={(value) => setWaterGoal(value[0])}
                className="[&>span]:bg-blue-500 dark:[&>span]:bg-blue-400"
              />
            </div>
          </div>
        </CardContent>
      </Card>

      <Card className="overflow-hidden border-none bg-background/60 backdrop-blur-lg shadow-xl">
        <CardHeader className="bg-gradient-to-r from-blue-500/10 to-cyan-500/10 dark:from-blue-500/20 dark:to-cyan-500/20">
          <CardTitle>Water Intake Tips</CardTitle>
          <CardDescription>Benefits of staying hydrated</CardDescription>
        </CardHeader>
        <CardContent className="p-6">
          <ul className="space-y-4">
            <motion.li
              className="flex items-start gap-2"
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.1 }}
            >
              <Droplet className="h-5 w-5 text-blue-500 dark:text-blue-400 mt-0.5 shrink-0" />
              <div>
                <p className="font-medium">Improves physical performance</p>
                <p className="text-sm text-muted-foreground">
                  Staying hydrated can significantly improve physical performance, especially during intense exercise.
                </p>
              </div>
            </motion.li>
            <motion.li
              className="flex items-start gap-2"
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.2 }}
            >
              <Droplet className="h-5 w-5 text-blue-500 dark:text-blue-400 mt-0.5 shrink-0" />
              <div>
                <p className="font-medium">Boosts energy levels</p>
                <p className="text-sm text-muted-foreground">
                  Water helps transport nutrients to your cells, giving you more energy throughout the day.
                </p>
              </div>
            </motion.li>
            <motion.li
              className="flex items-start gap-2"
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.3 }}
            >
              <Droplet className="h-5 w-5 text-blue-500 dark:text-blue-400 mt-0.5 shrink-0" />
              <div>
                <p className="font-medium">Improves brain function</p>
                <p className="text-sm text-muted-foreground">
                  Even mild dehydration can impair brain function, affecting mood, memory, and concentration.
                </p>
              </div>
            </motion.li>
            <motion.li
              className="flex items-start gap-2"
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.4 }}
            >
              <Droplet className="h-5 w-5 text-blue-500 dark:text-blue-400 mt-0.5 shrink-0" />
              <div>
                <p className="font-medium">Helps maintain healthy skin</p>
                <p className="text-sm text-muted-foreground">
                  Proper hydration helps keep your skin moisturized and may reduce the appearance of fine lines.
                </p>
              </div>
            </motion.li>
          </ul>
        </CardContent>
      </Card>
    </div>
  )
}
