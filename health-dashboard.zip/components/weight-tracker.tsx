"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Line, LineChart, XAxis, YAxis, CartesianGrid, ResponsiveContainer, Area, AreaChart } from "recharts"
import { ChartContainer, ChartTooltip, ChartTooltipContent } from "@/components/ui/chart"
import { Plus, Trash2, TrendingDown, TrendingUp, Minus } from "lucide-react"
import { motion, AnimatePresence } from "framer-motion"

interface WeightEntry {
  id: string
  date: string
  weight: number
  unit: "kg" | "lb"
  notes: string
}

export function WeightTracker() {
  const [entries, setEntries] = useState<WeightEntry[]>([
    { id: "1", date: "2023-05-01", weight: 75.5, unit: "kg", notes: "Starting weight" },
    { id: "2", date: "2023-05-05", weight: 75.2, unit: "kg", notes: "After first week of diet" },
    { id: "3", date: "2023-05-10", weight: 74.8, unit: "kg", notes: "Good progress" },
    { id: "4", date: "2023-05-15", weight: 74.3, unit: "kg", notes: "Consistent loss" },
    { id: "5", date: "2023-05-20", weight: 74.0, unit: "kg", notes: "Plateau starting" },
    { id: "6", date: "2023-05-25", weight: 73.9, unit: "kg", notes: "Breaking through plateau" },
    { id: "7", date: "2023-05-30", weight: 73.5, unit: "kg", notes: "End of month check-in" },
  ])

  const [newEntry, setNewEntry] = useState<Omit<WeightEntry, "id">>({
    date: new Date().toISOString().split("T")[0],
    weight: 70,
    unit: "kg",
    notes: "",
  })

  const [displayUnit, setDisplayUnit] = useState<"kg" | "lb">("kg")

  const handleAddEntry = () => {
    if (newEntry.weight > 0) {
      setEntries([
        ...entries,
        {
          id: Date.now().toString(),
          ...newEntry,
        },
      ])
      setNewEntry({
        date: new Date().toISOString().split("T")[0],
        weight: 70,
        unit: "kg",
        notes: "",
      })
    }
  }

  const handleDeleteEntry = (id: string) => {
    setEntries(entries.filter((entry) => entry.id !== id))
  }

  const convertWeight = (weight: number, fromUnit: "kg" | "lb", toUnit: "kg" | "lb") => {
    if (fromUnit === toUnit) return weight
    return fromUnit === "kg" ? weight * 2.20462 : weight / 2.20462
  }

  const getDisplayWeight = (entry: WeightEntry) => {
    return convertWeight(entry.weight, entry.unit, displayUnit).toFixed(1)
  }

  // Sort entries by date
  const sortedEntries = [...entries].sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime())

  // Prepare chart data
  const chartData = sortedEntries.map((entry) => ({
    date: new Date(entry.date).toLocaleDateString("en-US", { month: "short", day: "numeric" }),
    weight: Number(convertWeight(entry.weight, entry.unit, displayUnit).toFixed(1)),
  }))

  // Calculate stats
  const latestEntry = sortedEntries.length > 0 ? sortedEntries[sortedEntries.length - 1] : null
  const firstEntry = sortedEntries.length > 0 ? sortedEntries[0] : null

  const totalChange =
    latestEntry && firstEntry
      ? Number(convertWeight(latestEntry.weight, latestEntry.unit, displayUnit)) -
        Number(convertWeight(firstEntry.weight, firstEntry.unit, displayUnit))
      : 0

  const averageWeight =
    entries.length > 0
      ? entries.reduce((sum, entry) => sum + Number(convertWeight(entry.weight, entry.unit, displayUnit)), 0) /
        entries.length
      : 0

  return (
    <div className="grid gap-6 md:grid-cols-2">
      <Card className="overflow-hidden border-none bg-background/60 backdrop-blur-lg shadow-xl">
        <CardHeader className="bg-gradient-to-r from-cyan-500/10 to-blue-500/10 dark:from-cyan-500/20 dark:to-blue-500/20">
          <CardTitle>Weight Tracker</CardTitle>
          <CardDescription>Track your weight over time</CardDescription>
        </CardHeader>
        <CardContent className="p-6">
          <div className="space-y-4 mb-6">
            <div className="grid grid-cols-3 gap-4">
              <motion.div
                className="col-span-3 md:col-span-1"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.1 }}
              >
                <div className="text-center p-4 bg-gradient-to-br from-cyan-100 to-blue-100 dark:from-cyan-900/30 dark:to-blue-900/30 rounded-lg">
                  <div className="text-sm text-muted-foreground">Current</div>
                  <div className="text-2xl font-bold">{latestEntry ? getDisplayWeight(latestEntry) : "N/A"}</div>
                  <div className="text-xs text-muted-foreground">{displayUnit}</div>
                </div>
              </motion.div>
              <motion.div
                className="col-span-3 md:col-span-1"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.2 }}
              >
                <div className="text-center p-4 bg-gradient-to-br from-cyan-100 to-blue-100 dark:from-cyan-900/30 dark:to-blue-900/30 rounded-lg">
                  <div className="text-sm text-muted-foreground">Change</div>
                  <div
                    className={`text-2xl font-bold flex items-center justify-center ${
                      totalChange < 0 ? "text-green-500" : totalChange > 0 ? "text-red-500" : ""
                    }`}
                  >
                    {totalChange < 0 ? (
                      <TrendingDown className="mr-1 h-4 w-4" />
                    ) : totalChange > 0 ? (
                      <TrendingUp className="mr-1 h-4 w-4" />
                    ) : (
                      <Minus className="mr-1 h-4 w-4" />
                    )}
                    {Math.abs(totalChange).toFixed(1)}
                  </div>
                  <div className="text-xs text-muted-foreground">{displayUnit}</div>
                </div>
              </motion.div>
              <motion.div
                className="col-span-3 md:col-span-1"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.3 }}
              >
                <div className="text-center p-4 bg-gradient-to-br from-cyan-100 to-blue-100 dark:from-cyan-900/30 dark:to-blue-900/30 rounded-lg">
                  <div className="text-sm text-muted-foreground">Average</div>
                  <div className="text-2xl font-bold">{averageWeight.toFixed(1)}</div>
                  <div className="text-xs text-muted-foreground">{displayUnit}</div>
                </div>
              </motion.div>
            </div>
          </div>

          <div className="space-y-4">
            <div className="grid gap-2">
              <Label htmlFor="weight-date">Date</Label>
              <Input
                id="weight-date"
                type="date"
                value={newEntry.date}
                onChange={(e) => setNewEntry({ ...newEntry, date: e.target.value })}
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="grid gap-2">
                <Label htmlFor="weight-value">Weight</Label>
                <Input
                  id="weight-value"
                  type="number"
                  step="0.1"
                  min="0"
                  value={newEntry.weight}
                  onChange={(e) => setNewEntry({ ...newEntry, weight: Number.parseFloat(e.target.value) || 0 })}
                />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="weight-unit">Unit</Label>
                <Select
                  value={newEntry.unit}
                  onValueChange={(value: "kg" | "lb") => setNewEntry({ ...newEntry, unit: value })}
                >
                  <SelectTrigger id="weight-unit">
                    <SelectValue placeholder="Select unit" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="kg">Kilograms (kg)</SelectItem>
                    <SelectItem value="lb">Pounds (lb)</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="grid gap-2">
              <Label htmlFor="weight-notes">Notes</Label>
              <Input
                id="weight-notes"
                placeholder="Any notes about this measurement"
                value={newEntry.notes}
                onChange={(e) => setNewEntry({ ...newEntry, notes: e.target.value })}
              />
            </div>

            <motion.div whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }}>
              <Button
                className="w-full bg-gradient-to-r from-cyan-500 to-blue-500 hover:from-cyan-600 hover:to-blue-600"
                onClick={handleAddEntry}
                disabled={newEntry.weight <= 0}
              >
                <Plus className="mr-2 h-4 w-4" /> Add Weight Entry
              </Button>
            </motion.div>
          </div>
        </CardContent>
      </Card>

      <Card className="overflow-hidden border-none bg-background/60 backdrop-blur-lg shadow-xl">
        <CardHeader className="bg-gradient-to-r from-cyan-500/10 to-blue-500/10 dark:from-cyan-500/20 dark:to-blue-500/20">
          <div className="flex items-center justify-between">
            <div>
              <CardTitle>Weight History</CardTitle>
              <CardDescription>Visualize your progress</CardDescription>
            </div>
            <Select value={displayUnit} onValueChange={(value: "kg" | "lb") => setDisplayUnit(value)}>
              <SelectTrigger className="w-[120px]">
                <SelectValue placeholder="Display unit" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="kg">Kilograms</SelectItem>
                <SelectItem value="lb">Pounds</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardHeader>
        <CardContent className="p-6">
          <Tabs defaultValue="line">
            <TabsList className="grid w-full grid-cols-2 mb-4">
              <TabsTrigger value="line">Line Chart</TabsTrigger>
              <TabsTrigger value="area">Area Chart</TabsTrigger>
            </TabsList>

            <TabsContent value="line">
              <div className="h-[300px] mb-6">
                <ChartContainer
                  config={{
                    weight: {
                      label: `Weight (${displayUnit})`,
                      color: "hsl(var(--chart-1))",
                    },
                  }}
                >
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={chartData}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="date" />
                      <YAxis domain={["auto", "auto"]} tickCount={5} />
                      <ChartTooltip content={<ChartTooltipContent />} />
                      <Line
                        type="monotone"
                        dataKey="weight"
                        stroke="var(--color-weight)"
                        strokeWidth={2}
                        dot={{ r: 4 }}
                        activeDot={{ r: 6 }}
                      />
                    </LineChart>
                  </ResponsiveContainer>
                </ChartContainer>
              </div>
            </TabsContent>

            <TabsContent value="area">
              <div className="h-[300px] mb-6">
                <ChartContainer
                  config={{
                    weight: {
                      label: `Weight (${displayUnit})`,
                      color: "hsl(var(--chart-2))",
                    },
                  }}
                >
                  <ResponsiveContainer width="100%" height="100%">
                    <AreaChart data={chartData}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="date" />
                      <YAxis domain={["auto", "auto"]} tickCount={5} />
                      <ChartTooltip content={<ChartTooltipContent />} />
                      <Area
                        type="monotone"
                        dataKey="weight"
                        stroke="var(--color-weight)"
                        fill="var(--color-weight)"
                        fillOpacity={0.2}
                      />
                    </AreaChart>
                  </ResponsiveContainer>
                </ChartContainer>
              </div>
            </TabsContent>
          </Tabs>

          <div className="space-y-4">
            <h3 className="text-sm font-medium">Recent Entries</h3>
            <AnimatePresence>
              <div className="space-y-2">
                {sortedEntries
                  .slice()
                  .reverse()
                  .slice(0, 3)
                  .map((entry, index) => (
                    <motion.div
                      key={entry.id}
                      className="flex items-center justify-between p-3 border rounded-lg bg-gradient-to-r from-cyan-50 to-blue-50 dark:from-cyan-900/10 dark:to-blue-900/10"
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: -20 }}
                      transition={{ delay: index * 0.1 }}
                    >
                      <div>
                        <div className="font-medium">
                          {new Date(entry.date).toLocaleDateString("en-US", {
                            weekday: "short",
                            month: "short",
                            day: "numeric",
                          })}
                        </div>
                        <div className="text-sm text-muted-foreground">{entry.notes || "No notes"}</div>
                      </div>
                      <div className="flex items-center gap-4">
                        <div className="text-right">
                          <div className="font-medium">
                            {getDisplayWeight(entry)} {displayUnit}
                          </div>
                        </div>
                        <Button variant="ghost" size="icon" onClick={() => handleDeleteEntry(entry.id)}>
                          <Trash2 className="h-4 w-4 text-muted-foreground" />
                        </Button>
                      </div>
                    </motion.div>
                  ))}
              </div>
            </AnimatePresence>
          </div>
        </CardContent>
        <CardFooter className="flex justify-between border-t px-6 py-4">
          <div className="text-sm text-muted-foreground">Total Entries: {entries.length}</div>
          <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
            <Button
              variant="outline"
              size="sm"
              onClick={() => {
                const csvContent = [
                  ["Date", "Weight", "Unit", "Notes"].join(","),
                  ...sortedEntries.map((entry) => [entry.date, entry.weight, entry.unit, `"${entry.notes}"`].join(",")),
                ].join("\n")

                const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" })
                const url = URL.createObjectURL(blob)
                const link = document.createElement("a")
                link.setAttribute("href", url)
                link.setAttribute("download", "weight-history.csv")
                document.body.appendChild(link)
                link.click()
                document.body.removeChild(link)
              }}
            >
              Export Data
            </Button>
          </motion.div>
        </CardFooter>
      </Card>
    </div>
  )
}
